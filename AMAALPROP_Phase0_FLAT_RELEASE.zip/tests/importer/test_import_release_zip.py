import importlib.util
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile, ZipInfo

SCRIPT = Path(__file__).resolve().parents[2] / 'scripts' / 'import_release_zip.py'
spec = importlib.util.spec_from_file_location('release_importer', SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class ImportTests(unittest.TestCase):
    def make_zip(self, files):
        tmp = tempfile.TemporaryDirectory()
        path = Path(tmp.name) / 'update.zip'
        with ZipFile(path, 'w') as z:
            for name, contents in files.items():
                z.writestr(name, contents)
        return tmp, path

    def test_strip_exactly_one_wrapper(self):
        d, zipfile = self.make_zip({'AMAALPROP/apps/core-api/main.rs':'fn main() {}',
                                    'AMAALPROP/README.md':'unique readme'})
        with d:
            got = mod.get_sources(zipfile)
            self.assertIn('apps/core-api/main.rs', got)
            self.assertNotIn('AMAALPROP/apps/core-api/main.rs', got)

    def test_repeat_document_content_deduped(self):
        d, z = self.make_zip({'AMAALPROP/architecture.md':'same',
                              'AMAALPROP/docs/reference/architecture-v1.md':'same'})
        with d:
            got = mod.get_sources(z)
            self.assertEqual(list(got), ['architecture.md'])

    def test_reject_conflicting_duplicate_document(self):
        d, z = self.make_zip({'architecture.md':'first',
                              'docs/reference/architecture-v1.md':'second'})
        with d, self.assertRaisesRegex(ValueError,'Conflicting duplicated'):
            mod.get_sources(z)

    def test_reject_extra_wrapper(self):
        d, z = self.make_zip({'AMAALPROP/AMAALPROP/README.md':'oops'})
        with d, self.assertRaisesRegex(ValueError,'Nested'):
            mod.get_sources(z)

    def test_reject_path_traversal(self):
        d, z = self.make_zip({'AMAALPROP/../README.md':'unsafe'})
        with d, self.assertRaises(ValueError):
            mod.get_sources(z)

    def test_reject_case_collision(self):
        d, z = self.make_zip({'README.md':'one','readme.md':'two'})
        with d, self.assertRaises(ValueError):
            mod.get_sources(z)

    def test_reject_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            z = Path(d)/'update.zip'
            i=ZipInfo('apps/link'); i.create_system = 3; i.external_attr = (0o120777 << 16)
            with ZipFile(z,'w') as out: out.writestr(i,'../outside')
            with self.assertRaises(ValueError): mod.get_sources(z)

    def test_manifest_replaces_and_prunes_stale(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            mod.apply(root, {'README.md':b'original','apps/app.ts':b'v1'})
            mod.apply(root, {'README.md':b'revised'})
            self.assertFalse((root/'apps/app.ts').exists())
            self.assertEqual((root/'README.md').read_bytes(), b'revised')

if __name__ == '__main__': unittest.main()
