# AMAALPROP — ZIP import workflow

## What the workflow does

The tracked workflow `.github/workflows/import-release-zip.yml` runs automatically **after a complete ZIP is uploaded directly into `incoming/` on `main`**. It also supports manual dispatch with the path to an existing `incoming/*.zip`. GitHub Actions cannot directly accept a binary upload through the Run workflow button; first upload the ZIP to the repository.

The workflow performs safe extraction into the **repository root**, never a nested `AMAALPROP/` directory. It supports the one wrapper folder in older AMAALPROP ZIPs, but refuses repeated wrappers, paths with `..`, case-colliding archive names, symlinks, encrypted archives, and unexpected top-level directories. It canonicalizes the four duplicated historical reference documents to their root names, deduplicates exactly identical Markdown content, refuses conflicting copies and uses a tracked checksum manifest to remove stale files from later **complete** snapshots.

It deliberately **does not execute code from the imported ZIP before review**, does not publish services, and does not merge changes automatically. It commits the imported code to a named branch and opens a pull request. A maintainer should review that PR and let CI pass before merging. The incoming ZIP is deleted by the PR, so the imported repository retains only canonical source files rather than an archive + extracted duplicate.

## One-time bootstrap

Since the AMAALPROP GitHub repository currently contains documents only, it must first contain the workflow **and** its helper script. Add these paths to the repository before uploading the first ZIP:

- `.github/workflows/import-release-zip.yml`
- `scripts/import_release_zip.py`

Enable GitHub Actions **Read and write permissions** for this repository and **Allow GitHub Actions to create and approve pull requests** (if the repository policy permits it). Grant the GitHub integration repository write access if you want ChatGPT to publish files directly; the read-only connection currently rejects file creation with HTTP 403.

## Every release

1. Produce a **full repository snapshot ZIP** (not a patch/delta). The archive may contain source files at ZIP root or inside exactly one `AMAALPROP/` wrapper.
2. Upload it to `incoming/AMAALPROP-release-YYYYMMDD.zip` on the `main` branch. Keep exactly one pending ZIP in `incoming/`.
3. Review the automatically opened `AMAALPROP: import ZIP into clean repository root` PR.
4. Merge only after checks pass and inspect Render Blueprint plans before deployment, especially when paid resources or secrets are affected.
5. Leave `.github/workflows/import-release-zip.yml` intact; update it through a separate reviewed PR, never through an archive.

The workflow is scoped to `MONALISA2003-CMD/AMAALPROP` and does not touch unrelated projects.
