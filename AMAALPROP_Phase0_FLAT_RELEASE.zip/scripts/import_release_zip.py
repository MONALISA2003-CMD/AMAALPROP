#!/usr/bin/env python3
"""Strict, repeatable AMAALPROP ZIP importer for GitHub Actions.

The archive may have either no wrapper or exactly one AMAALPROP/ wrapper.
Imported files land in the repository root, never AMAALPROP/AMAALPROP/.
The manifest tracks imported paths so later imports safely remove stale files.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

REPO = Path(__file__).resolve().parents[1]
MANIFEST = Path('.github/amaalprop-import-manifest.json')
CANONICAL_REFERENCE = {
    'docs/reference/ERD-v1.md': 'AMAALPROP_ERD_Full.md',
    'docs/reference/PRD-v1.md': 'AMAALPROP_Product_Requirements_Document_v1.md',
    'docs/reference/architecture-v1.md': 'architecture.md',
    'docs/reference/tech-stack-v1.md': 'tech-stack.md',
}
ALLOWED_TOP = {'apps', 'crates', 'packages', 'contracts', 'database', 'docs',
               'infrastructure', 'scripts', 'tests', '.github'}
ALLOWED_ROOT = {'.dockerignore', '.editorconfig', '.env.example', '.gitignore',
                'Cargo.lock', 'Cargo.toml', 'README.md', 'README-START-HERE.md',
                'PHASE0-REPAIR-NOTES.md', 'PHASE0-DEPLOYMENT-STATUS.md', 'SECURITY.md', 'render.yaml',
                'compose.yaml', 'phases.md', 'repo-structure.md', 'architecture.md',
                'tech-stack.md', 'AMAALPROP_ERD_Full.md',
                'AMAALPROP_Product_Requirements_Document_v1.md', 'package.json',
                'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'rust-toolchain.toml'}
DENY_PARTS = {'.git', '.venv', '__pycache__', 'node_modules', '.next', 'target',
              '.terraform', '.pnpm-store', '.DS_Store'}
BLOCKED = {MANIFEST.as_posix(), '.github/workflows/import-release-zip.yml'}
MAX_FILES = 2000
MAX_TOTAL = 150 * 1024 * 1024
MAX_FILE = 30 * 1024 * 1024


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def valid_name(name: str) -> str:
    if not name or '\\' in name or '\x00' in name or name.startswith('/'):
        raise ValueError(f'Unsafe archive member: {name!r}')
    path = PurePosixPath(name.rstrip('/'))
    if not path.parts or any(part in ('', '.', '..') for part in name.rstrip('/').split('/')):
        raise ValueError(f'Unsafe archive path: {name!r}')
    if ':' in path.parts[0] or any(part in DENY_PARTS for part in path.parts):
        raise ValueError(f'Prohibited archive path: {name!r}')
    return path.as_posix()


def get_sources(archive: Path) -> dict[str, bytes]:
    if not zipfile.is_zipfile(archive):
        raise ValueError('Input must be a ZIP file')
    with zipfile.ZipFile(archive) as z:
        members = [x for x in z.infolist() if not x.is_dir()]
        if not members or len(members) > MAX_FILES:
            raise ValueError('Archive empty or exceeds file count limit')
        total = sum(x.file_size for x in members)
        if total > MAX_TOTAL or any(x.file_size > MAX_FILE for x in members):
            raise ValueError('Archive size exceeds safe limit')
        names = [valid_name(info.filename) for info in members]
        # Only the historical single AMAALPROP/ prefix is stripped.
        if all(n.startswith('AMAALPROP/') for n in names):
            names = [n[len('AMAALPROP/'):] for n in names]
        if any(n.startswith('AMAALPROP/') or n == 'AMAALPROP' for n in names):
            raise ValueError('Nested AMAALPROP folder is not allowed')
        seen_case = set()
        data = {}
        for name, info in zip(names, members):
            if not name:
                raise ValueError('Empty file path after wrapper normalization')
            key = name.casefold()
            if key in seen_case:
                raise ValueError(f'Archive contains repeated or case-colliding file: {name}')
            seen_case.add(key)
            mode = (info.external_attr >> 16) & 0xffff
            if stat.S_ISLNK(mode):
                raise ValueError(f'Symlink not allowed in archive: {name}')
            if info.flag_bits & 1:
                raise ValueError(f'Encrypted member not supported: {name}')
            p = PurePosixPath(name)
            if p.parts[0] not in ALLOWED_TOP and name not in ALLOWED_ROOT:
                raise ValueError(f'Unexpected repo-root file or folder: {name}')
            if name.startswith('.github/workflows/') and name in BLOCKED:
                # Never let a ZIP modify the importer that inspects that ZIP.
                continue
            if name in BLOCKED or name.startswith('incoming/') or name.startswith('imports/'):
                raise ValueError(f'Importer-owned path in ZIP: {name}')
            data[name] = z.read(info)
    # Canonicalize legacy duplicate PRD/ERD/architecture copies to root.
    for old, new in CANONICAL_REFERENCE.items():
        if old not in data:
            continue
        payload = data.pop(old)
        if new in data and data[new] != payload:
            raise ValueError(f'Conflicting duplicated documents: {old} and {new}')
        data.setdefault(new, payload)
    # Reject exact repeated documentation content even under different names.
    document_hashes = {}
    for name in sorted(list(data)):
        if not name.lower().endswith('.md'):
            continue
        digest = sha(data[name])
        prior = document_hashes.get(digest)
        if prior is not None:
            # Deterministic dedupe: retain first path, omit repeated content.
            del data[name]
        else:
            document_hashes[digest] = name
    return data


def read_manifest(repo: Path) -> dict[str, str]:
    path = repo / MANIFEST
    if not path.exists():
        return {}
    obj = json.loads(path.read_text('utf-8'))
    if obj.get('schema') != 1 or not isinstance(obj.get('files'), dict):
        raise ValueError('Unknown import manifest schema')
    return obj['files']


def apply(repo: Path, data: dict[str, bytes]) -> dict[str, int]:
    old = read_manifest(repo)
    new = {name: sha(contents) for name, contents in sorted(data.items())}
    # Detect manual edits of previously imported files; never silently overwrite them.
    for name, expected in old.items():
        p = repo / name
        if p.is_symlink() or (p.exists() and sha(p.read_bytes()) != expected):
            raise ValueError(f'Manually modified imported file; review before replacing: {name}')
    for name, contents in data.items():
        target = repo / name
        if target.is_symlink():
            raise ValueError(f'Symlink at destination: {name}')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(contents)
    removed = 0
    for name in old.keys() - new.keys():
        if name in BLOCKED:
            raise ValueError(f'Protected path in prior manifest: {name}')
        p = repo / name
        if p.is_file():
            p.unlink()
            removed += 1
    # The old repository has the same v1 references twice; remove exact copies only.
    for old_name, root_name in CANONICAL_REFERENCE.items():
        old_path, root_path = repo / old_name, repo / root_name
        if old_path.is_file() and root_path.is_file() and old_path.read_bytes() == root_path.read_bytes():
            old_path.unlink()
            removed += 1
    (repo / MANIFEST).parent.mkdir(parents=True, exist_ok=True)
    (repo / MANIFEST).write_text(
        json.dumps({'schema': 1, 'files': new}, indent=2, sort_keys=True) + '\n', 'utf-8')
    return {'files': len(new), 'removed': removed}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('zip_path', type=Path)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    archive = args.zip_path.resolve(strict=True)
    repo = args.repo.resolve(strict=True)
    payload = get_sources(archive)
    required_snapshot = {'README.md', 'phases.md', 'repo-structure.md', 'render.yaml',
                         'apps/api-gateway/src/main.ts', 'apps/core-api/src/main.rs',
                         'apps/worker/src/main.rs', 'scripts/import_release_zip.py'}
    if not args.dry_run and not required_snapshot.issubset(payload):
        raise ValueError('Only complete AMAALPROP source snapshots are supported; missing: ' +
                         ', '.join(sorted(required_snapshot - payload.keys())))
    if args.dry_run:
        print(json.dumps({'archive': archive.name, 'canonical_paths': sorted(payload),
                          'count': len(payload)}, indent=2))
        return
    summary = apply(repo, payload)
    print(f'AMAALPROP ZIP imported: {summary["files"]} unique canonical files; '
          f'{summary["removed"]} obsolete duplicates removed; repository root unchanged.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        print(f'REJECTED: {exc}', file=sys.stderr)
        sys.exit(2)
