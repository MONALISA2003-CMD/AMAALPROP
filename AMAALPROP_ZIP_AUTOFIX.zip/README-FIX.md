# AMAALPROP — ZIP import repair

## Root cause
The workflow ran scripts/import_release_zip.py before the ZIP had been extracted. The script did not yet exist in the checked-out repository.

## Minimal one-time repair
Replace the EXISTING `.github/workflows/import-release-zip.yml` on the `main` branch with the workflow in this archive. You do NOT need to manually install the script: the updated YAML bootstraps it from embedded, audited source on every run.

The workflow detects any committed .zip/.ZIP file anywhere in AMAALPROP, flattens extra wrapper folders, validates paths and collisions, deduplicates identical documentation, extracts into the root, removes ZIPs, and commits the organized repository.

## After editing the YAML
Commit the workflow update to `main`. A normal push triggers the importer immediately, including the ZIP already in the repo. Verify Actions -> the latest workflow run is green and `apps/api-gateway`, `apps/core-api`, `apps/worker`, `apps/web`, and `scripts` appear at repo root.

## If the final commit/push fails
Under Settings > Actions > General set Workflow permissions to Read and write, then verify branch rules on `main` permit GitHub Actions writes (or switch to PR-based import). Do not disable protections broadly.

## Tested locally
The attached Phase 0 ZIP imports successfully on the first run even when scripts/ does not exist. A future ZIP without the script also imports successfully, with no nested AMAALPROP root.
