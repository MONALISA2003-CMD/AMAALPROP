# AMAALPROP — Phase 0 repaired engineering foundation

> **Synthetic-only; not deployed by this archive.** There is no real user login,
> payments, authorised tenant query, or production-ready database integration here.

Only the `AMAALPROP` repository and `amaalprop-v2-staging` Neon project are in scope.
Do **not** attach another product's Render services, Vercel site, domains or R2 buckets.

## What is in this repository

- Next.js buildable web placeholder (Vercel connection is deferred)
- NestJS public gateway and signed staging-only core smoke probe
- Rust/Axum private core with signed assertion verification
- Rust worker (idle by design)
- Synthetic, *transaction-rolled-back* local PostgreSQL RLS test
- Dockerfiles / Compose / CI checks / provisional OpenAPI / original v1+v2 design docs

## Local commands

Toolchain pins are in `package.json`, `rust-toolchain.toml`, and Dockerfiles.
Follow `docs/phase0-runbook.md` for exact steps and security warnings.

```sh
node scripts/doctor.mjs
node scripts/verify-openapi.mjs
pnpm install --frozen-lockfile
pnpm build && pnpm typecheck
cargo fmt --all --check && cargo clippy --locked --all-targets -- -D warnings
cargo test --locked && cargo build --locked
```

To exercise live smoke tests locally, generate unique secrets into an ignored `.env`
file, then run `docker compose up --build` and `pnpm run test:boundary`.
Run the ephemeral RLS test against a **local disposable Postgres** only.

## Remote resources checked (read-only on 13 November 2026)

| Provider | Confirmed for AMAALPROP | What remains |
|---|---|---|
| GitHub | `MONALISA2003-CMD/AMAALPROP` repo exists, `main` has six design documents | Publish and review this scaffold; GitHub write access not verified |
| Neon | `amaalprop-v2-staging`, Frankfurt, PostgreSQL 17; `development` and `staging` branches; staging has no application tables | Define restricted runtime/migrator roles and attach secrets when P1 SQL is approved |
| Render | **No AMAALPROP services visible** in the only accessible Render workspace | Locate correct workspace/services; do not create duplicates |
| Vercel | No verified AMAALPROP web app connected to this repository | Deferred; not needed for P0 local/back-end gate |

Do not run external customer-data imports or execute financial postings until the
separate production launch gates have been approved.

## Repeatable ZIP imports and Render rollout (2026-11-14)

Use `.github/workflows/import-release-zip.yml` and `scripts/import_release_zip.py`. See [GitHub ZIP import instructions](docs/github-zip-import.md) and [Render Phase 0 setup](docs/render-phase0-setup.md).

The import workflow requires a *full* source snapshot ZIP; it canonicalizes paths at the repository root, removes repeated historical docs, and opens a review PR instead of pushing imported code directly to main. The Render Blueprint is synthetic only; no database connection or production deployment is implied. Live deployment and CI remain pending until the current GitHub App access blocker is resolved.
