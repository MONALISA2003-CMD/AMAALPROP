import {readFileSync, existsSync} from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const read = p => readFileSync(p,'utf8');
const required = ['phases.md','repo-structure.md','README.md','docs/phase-0-status.md','render.yaml',
 'contracts/openapi/amaalprop-v1.yaml','apps/web/package.json','apps/api-gateway/src/main.ts',
 'apps/core-api/src/main.rs','apps/worker/src/main.rs','database/tests/phase0_rls_ephemeral.sql'];
for(const f of required) assert.ok(existsSync(f),`Missing: ${f}`);
for(const p of ['architecture.md','tech-stack.md','AMAALPROP_ERD_Full.md','AMAALPROP_Product_Requirements_Document_v1.md']) {
 assert.ok(read(p).length>5000, `Original documentation replaced by placeholder: ${p}`);
}
assert.match(read('render.yaml'),/name: amaalprop-v2-core/);
assert.match(read('render.yaml'),/type: pserv/);
assert.match(read('render.yaml'),/name: amaalprop-v2-gateway/);
assert.match(read('render.yaml'),/name: amaalprop-v2-worker/);
assert.ok(!existsSync('database/migrations/0001_synthetic_rls_probe.sql'), 'Persistent P0 test fixture must not be a migration');
assert.ok(!existsSync('.env'), 'Local .env must not be part of repository snapshot');
for (const p of ['apps/api-gateway/src/main.ts','apps/core-api/src/main.rs','apps/worker/src/main.rs']){
 assert.match(read(p),/synthetic/i, `Missing synthetic-only gate: ${p}`);
}
console.log('AMAALPROP Phase 0 file, boundary and documentation checks: OK');
console.log('This is not a build or live deployment verification.');
