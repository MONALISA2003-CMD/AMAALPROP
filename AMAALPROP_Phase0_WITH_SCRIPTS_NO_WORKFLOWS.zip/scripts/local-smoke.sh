#!/usr/bin/env bash
set -euo pipefail
: "${STAGING_SMOKE_TOKEN:?Set STAGING_SMOKE_TOKEN for synthetic-only smoke test}"
url="${GATEWAY_URL:-http://127.0.0.1:10000}"
echo "Public gateway liveness:"
curl --fail --silent --show-error "${url}/api/v1/health"
echo
echo "Private core via signed gateway request (operator secret):"
curl --fail --silent --show-error -H "Authorization: Bearer ${STAGING_SMOKE_TOKEN}" "${url}/api/v1/core-health"
echo
