#!/usr/bin/env python3
"""Safely import ALL committed ZIP archives into a flat AMAALPROP monorepo.

Use from the repository root via: python3 scripts/import_release_zip.py --auto
The importer never executes archive contents and refuses unsafe/colliding paths.
An import manifest tracks its own files for safe incremental updates.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import zipfile

REPO = Path(__file__).resolve().parents[1]
MANIFEST = '.github/amaalprop-import-manifest.json'
PROTECTED = {
    MANIFEST,
    '.github/workflows/import-release-zip.yml',
    'scripts/import_release_zip.py',
}
PROTECTED_CASE = {name.casefold() for name in PROTECTED}
ALLOWED_DIRS = {
    '.github', 'apps', 'crates', 'packages', 'contracts', 'database',
    'docs', 'infrastructure', 'scripts', 'tests', 'tools', 'config',
}
ALLOWED_ROOT_FILES = {
    '.dockerignore', '.editorconfig', '.env.example', '.gitignore',
    '.gitattributes', 'Cargo.lock', 'Cargo.toml', 'Dockerfile',
    'README.md', 'README-START-HERE.md', 'SECURITY.md', 'CODEOWNERS',
    'PHASE0-REPAIR-NOTES.md', 'PHASE0-DEPLOYMENT-STATUS.md',
    'AMAALPROP_ERD_Full.md', 'AMAALPROP_Product_Requirements_Document_v1.md',
    'AMAALPROP_ERD_v2_FINAL.md', 'architecture.md', 'architecture-v2.md',
    'phases.md', 'repo-structure.md', 'tech-stack.md', 'START-HERE.md',
    'financial-workflows-v2.md', 'identity-membership-v2.md',
    'product-policy-decisions-v2.md', 'hosting-data-protection-v2.md',
    'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml',
    'package-lock.json', 'yarn.lock', 'bun.lockb', 'bun.lock',
    'rust-toolchain.toml', 'render.yaml', 'render.yml',
    'compose.yaml', 'compose.yml', 'docker-compose.yaml',
    'docker-compose.yml', 'Makefile', 'justfile',
    '.prettierrc', '.prettierrc.json', '.eslintrc.json',
}
# Exact historical v1 documents are kept at root, not repeated at docs/reference/.
DOC_ALIASES = {
    'docs/reference/ERD-v1.md': 'AMAALPROP_ERD_Full.md',
    'docs/reference/PRD-v1.md': 'AMAALPROP_Product_Requirements_Document_v1.md',
    'docs/reference/architecture-v1.md': 'architecture.md',
    'docs/reference/tech-stack-v1.md': 'tech-stack.md',
}
DENY_PARTS = {
    '.git', '.venv', '__pycache__', 'node_modules', '.next', 'target',
    '.terraform', '.pnpm-store', '.DS_Store', '.idea', '.vscode',
}
MAX_ARCHIVES = 50
MAX_FILES = 4000
MAX_EACH_FILE = 40 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED = 180 * 1024 * 1024
MAX_RATIO = 350


def sha(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def safe_path(raw: str) -> str:
    if not raw or raw[0] == '/' or '\\' in raw or '\x00' in raw:
        raise ValueError(f'unsafe absolute/Windows archive path: {raw!r}')
    # Zip members use forward slashes on all platforms.
    parts = raw.split('/')
    if not parts or any(part in {'', '.', '..'} for part in parts):
        raise ValueError(f'unsafe path segment: {raw!r}')
    if ':' in parts[0] or any(part in DENY_PARTS for part in parts):
        raise ValueError(f'forbidden segment in: {raw!r}')
    return PurePosixPath(raw).as_posix()


def is_repo_layout(name: str) -> bool:
    head = name.split('/', 1)[0]
    return (head in ALLOWED_DIRS if '/' in name else name in ALLOWED_ROOT_FILES)


def flatten_wrappers(names: list[str]) -> list[str]:
    # Strip ANY common wrapper folder (release name, AMAALPROP, GitHub download
    # folder, etc.), but never strip a legitimate monorepo directory like apps/.
    result = names[:]
    for _ in range(7):
        heads = {n.split('/', 1)[0] for n in result}
        if len(heads) != 1 or any('/' not in n for n in result):
            break
        head = next(iter(heads))
        if head in ALLOWED_DIRS or head in ALLOWED_ROOT_FILES:
            break
        result = [n.split('/', 1)[1] for n in result]
    return result


def read_archive(path: Path) -> dict[str, bytes]:
    if not zipfile.is_zipfile(path):
        raise ValueError(f'not a ZIP archive: {path.name}')
    with zipfile.ZipFile(path) as z:
        entries = [m for m in z.infolist() if not m.is_dir()]
        if not entries or len(entries) > MAX_FILES:
            raise ValueError(f'archive empty or too many entries: {path}')
        if sum(m.file_size for m in entries) > MAX_TOTAL_UNCOMPRESSED:
            raise ValueError(f'archive expanded size too large: {path}')
        for member in entries:
            if member.file_size > MAX_EACH_FILE:
                raise ValueError(f'oversized member: {member.filename}')
            if member.compress_size and member.file_size / member.compress_size > MAX_RATIO:
                raise ValueError(f'excessive compression ratio: {member.filename}')
            if member.flag_bits & 1:
                raise ValueError(f'encrypted ZIP entry unsupported: {member.filename}')
            if stat.S_ISLNK((member.external_attr >> 16) & 0xffff):
                raise ValueError(f'ZIP symlink forbidden: {member.filename}')
        names = flatten_wrappers([safe_path(m.filename) for m in entries])
        data: dict[str, bytes] = {}
        canonical_case: dict[str, str] = {}
        for name, member in zip(names, entries):
            safe_path(name)
            if name.casefold() in PROTECTED_CASE:
                # Bootstrap/source snapshots may contain old copies. The importer
                # MUST NOT replace its own security-sensitive workflow or script.
                continue
            if name.lower().endswith('.zip'):
                raise ValueError(f'nested archive forbidden: {name}')
            if not is_repo_layout(name):
                raise ValueError(f'not a recognized AMAALPROP root path: {name}')
            binary = z.read(member)
            lowered = name.casefold()
            if lowered in canonical_case:
                prior_name = canonical_case[lowered]
                if prior_name != name or data[prior_name] != binary:
                    raise ValueError(f'conflicting duplicate paths: {prior_name} vs {name}')
                continue  # Bit-for-bit duplicate entry: keep only one.
            canonical_case[lowered] = name
            data[name] = binary
        return data


def list_archives(repo: Path) -> list[str]:
    # Only committed files, not .git internals or untracked build outputs.
    proc = subprocess.run(['git', 'ls-files', '-z'], cwd=repo,
                          check=True, stdout=subprocess.PIPE)
    result = []
    for raw in proc.stdout.split(b'\x00'):
        if not raw:
            continue
        name = os.fsdecode(raw)
        if not name.lower().endswith('.zip'):
            continue
        safe_path(name)
        path = repo / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'archive must be a regular file: {name}')
        result.append(name)
    if len(result) > MAX_ARCHIVES:
        raise ValueError('too many ZIP archives committed at once')
    return sorted(result, key=str.casefold)


def resolve_docs(data: dict[str, bytes]) -> dict[str, bytes]:
    # Apply explicit aliases BEFORE checking identical document content.
    for alias, canonical in DOC_ALIASES.items():
        if alias not in data:
            continue
        blob = data.pop(alias)
        if canonical in data and data[canonical] != blob:
            raise ValueError(f'nonidentical historical document copies: {alias}')
        data.setdefault(canonical, blob)
    seen_hashes: dict[str, str] = {}
    # Root canonical Markdown first, then docs/, then other Markdown paths.
    paths = sorted(data, key=lambda n: (0 if '/' not in n else 1 if n.startswith('docs/') else 2, n.casefold()))
    for name in paths:
        if not name.lower().endswith('.md'):
            continue
        hash_ = sha(data[name])
        if hash_ in seen_hashes:
            # Exact duplicate document; keep a single canonical copy.
            del data[name]
        else:
            seen_hashes[hash_] = name
    return data


def merge_archives(repo: Path, archives: list[str]) -> dict[str, bytes]:
    merged: dict[str, bytes] = {}
    seen_case: dict[str, str] = {}
    total = 0
    for zip_name in archives:
        files = read_archive(repo / zip_name)
        for name, payload in files.items():
            total += len(payload)
            if total > MAX_TOTAL_UNCOMPRESSED:
                raise ValueError('all archives together exceed expanded size limit')
            lower = name.casefold()
            if lower in seen_case:
                prior = seen_case[lower]
                if prior != name or merged[prior] != payload:
                    raise ValueError(f'ZIPs disagree on {name!r}; upload one version')
            else:
                seen_case[lower] = name
                merged[name] = payload
    return resolve_docs(merged)


def read_manifest(repo: Path) -> dict[str, str]:
    p = repo / MANIFEST
    if not p.exists():
        return {}
    j = json.loads(p.read_text(encoding='utf-8'))
    if j.get('schema') != 1 or not isinstance(j.get('files'), dict):
        raise ValueError('unexpected manifest format')
    manifest = j['files']
    for name, checksum in manifest.items():
        safe_path(name)
        if not isinstance(checksum, str) or len(checksum) != 64:
            raise ValueError(f'bad checksum for {name}')
    return manifest


def ensure_not_symlink(repo: Path, relative: str) -> Path:
    cursor = repo
    for part in PurePosixPath(relative).parts:
        cursor /= part
        if cursor.is_symlink():
            raise ValueError(f'unsafe destination symlink: {relative}')
    return cursor


def apply_import(repo: Path, archives: list[str], payload: dict[str, bytes]) -> tuple[int, int]:
    old = read_manifest(repo)
    updated = {name: sha(blob) for name, blob in payload.items()}
    # Reject files whose names differ only in case from existing tracked paths.
    tracked = subprocess.run(['git', 'ls-files', '-z'], cwd=repo, check=True,
                             stdout=subprocess.PIPE).stdout
    tracked_case = {}
    for raw in tracked.split(b'\x00'):
        if not raw:
            continue
        tracked_name = os.fsdecode(raw)
        tracked_case.setdefault(tracked_name.casefold(), tracked_name)
    for name in payload:
        prior = tracked_case.get(name.casefold())
        if prior is not None and prior != name:
            raise ValueError(f'case-collision with existing file: {prior} / {name}')
        parts = PurePosixPath(name).parts
        if any('/'.join(parts[:i]) in payload for i in range(1, len(parts))):
            raise ValueError(f'file/directory collision in archive: {name}')
    # Verify imported file integrity BEFORE modifying files.
    for name, current_hash in old.items():
        if name in PROTECTED:
            continue  # Legacy manifest may have tracked installer files.
        p = ensure_not_symlink(repo, name)
        if p.exists() and (not p.is_file() or sha(p.read_bytes()) != current_hash):
            raise ValueError(f'manually edited imported file; refusing overwrite: {name}')
    for name in payload:
        target = ensure_not_symlink(repo, name)
        if target.exists() and not target.is_file():
            raise ValueError(f'destination is not a file: {name}')
    for name in archives:
        ensure_not_symlink(repo, name)
    for name, blob in payload.items():
        p = repo / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(blob)
    # Incremental archives are supported: do NOT delete files omitted from a ZIP.
    # Missing paths are not proof that a file should be removed.
    obsolete = 0
    # Remove historical duplicate v1 docs only if byte-for-byte equal.
    for alias, canonical in DOC_ALIASES.items():
        p = ensure_not_symlink(repo, alias)
        q = ensure_not_symlink(repo, canonical)
        if p.is_file() and q.is_file() and p.read_bytes() == q.read_bytes():
            p.unlink()
            obsolete += 1
    # Consolidate exact duplicate documentation across existing root + docs/.
    # Never dedupe app/module source files: equal code can be intentional.
    root_docs = [repo / n for n in ALLOWED_ROOT_FILES if n.lower().endswith('.md') and (repo / n).is_file()]
    doc_files = [p for p in (repo / 'docs').rglob('*.md') if p.is_file() and not p.is_symlink()] if (repo / 'docs').is_dir() else []
    dup_sha: dict[str, Path] = {}
    for document in sorted(root_docs, key=lambda p: p.name) + sorted(doc_files):
        checksum = sha(document.read_bytes())
        if checksum in dup_sha and document.is_relative_to(repo / 'docs'):
            ensure_not_symlink(repo, document.relative_to(repo).as_posix())
            document.unlink()
            obsolete += 1
        else:
            dup_sha.setdefault(checksum, document)
    for name in archives:
        (repo / name).unlink()
    manifest_path = repo / MANIFEST
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    surviving_old = {name: checksum for name, checksum in old.items()
                     if name not in PROTECTED and (repo / name).is_file()}
    surviving_old.update({name: checksum for name, checksum in updated.items()
                          if (repo / name).is_file()})
    manifest_path.write_text(json.dumps({'schema': 1, 'files': surviving_old}, indent=2,
                                        sort_keys=True) + '\n', encoding='utf-8')
    return len(payload), obsolete


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--auto', action='store_true', help='detect all tracked ZIP files anywhere in repository')
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if not args.auto:
        parser.error('use --auto; archive names are intentionally detected automatically')
    repo = args.repo.resolve(strict=True)
    archives = list_archives(repo)
    if not archives:
        print('No committed ZIP files found. Nothing to import.')
        return
    print(f'Detected {len(archives)} ZIP archive(s): {archives}')
    data = merge_archives(repo, archives)
    if args.dry_run:
        print(f'Dry run validated {len(data)} canonical repository files; no changes.')
        return
    n, removed = apply_import(repo, archives, data)
    print(f'Imported {n} canonical files; removed {removed} obsolete/duplicate files and {len(archives)} ZIP archives.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile, subprocess.CalledProcessError) as exc:
        print(f'AMAALPROP ZIP import REJECTED: {exc}', file=sys.stderr)
        sys.exit(2)
