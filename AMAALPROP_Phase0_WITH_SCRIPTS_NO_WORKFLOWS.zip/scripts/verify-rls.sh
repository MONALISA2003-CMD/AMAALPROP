#!/usr/bin/env bash
set -euo pipefail
: "${TEST_DATABASE_URL:?Set TEST_DATABASE_URL for a disposable LOCAL PostgreSQL database}"
# Parse the URL instead of matching a shell substring: credentials are allowed but
# any non-loopback host is refused. Never run test fixture against Neon/staging.
node - <<'NODE'
const raw = process.env.TEST_DATABASE_URL;
let url;
try { url = new URL(raw); } catch { console.error('Invalid TEST_DATABASE_URL'); process.exit(2); }
if (!['postgres:', 'postgresql:'].includes(url.protocol) || !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) {
  console.error('Refusing Phase 0 RLS fixture against non-local PostgreSQL');
  process.exit(2);
}
NODE
psql "$TEST_DATABASE_URL" -X -v ON_ERROR_STOP=1 -f database/tests/phase0_rls_ephemeral.sql
