# Security

Synthetic development only. No customer data or financial activity is permitted before the P9 release gate.
Report security issues privately to the repository owner; do not post credentials or personal data in public issues.
Gateway and web never receive a database owner credential. The core must remain a Render private service.
