# AMAALPROP — Start Here: v2 Design Pack

**Date:** 13 November 2026. **Purpose:** The engineering decisions and updated logical model required before coding AMAALPROP. The pack does **not** contain a built application or evidence of legal/financial compliance approval.

## Decision in one sentence

**Use Next.js (web) + NestJS (public authenticated API gateway) + Rust/Axum (sole authoritative modular core) + Rust worker + Neon PostgreSQL with RLS + private Cloudflare R2; Python AI is optional later.** Put them in one GitHub monorepo. No duplicate NestJS/Rust financial or property-management backends.

## What to put in your GitHub repository

- `repo-structure.md` and `phases.md` at the repository root.
- Copy all `docs/*.md` into the repository's `docs/` folder.
- Keep the original four documents in `docs/reference/` as historical v1 baselines, **not** as conflicting implementation instructions.
- P0 scaffolding then creates the actual `apps/`, `crates/`, `packages/`, `contracts/`, `database/`, `infrastructure/`, `tests/`, `.github/` and `scripts/` directories described by `repo-structure.md`.

## Read in this order

1. `docs/architecture-v2.md` — which runtime owns which responsibility and the complete trust boundary.
2. `docs/identity-membership-v2.md` — canonical email, one organisation per active login, same-org dual roles, invitation/owner transfers, scopes, IAM.
3. `docs/AMAALPROP_ERD_v2_FINAL.md` — all core/v1 entities retained, missing v2 entities, constraints, keys, lifecycle state models and source migration map.
4. `docs/financial-workflows-v2.md` — invoice, payment verification, receipt, unapplied credit, ledger, refund, supplier/AP and clearance posting rules.
5. `docs/hosting-data-protection-v2.md` — Frankfurt candidate topology, R2 EU jurisdiction, Uganda legal requirements, provider and production release gates.
6. `repo-structure.md` — final monorepo layout and first-commit rules.
7. `docs/product-policy-decisions-v2.md` — each of the PRD’s 12 open questions now has an explicit default and sign-off status.
8. `phases.md` — P0 through P10 with exit gates.

## Source of truth and conflict resolution

Precedence for **initial engineering implementation** is: v2 decisions > v1 detailed PRD for unchanged product requirements > v1 ERD for unchanged legacy entity fields > original infrastructure stack as context. A conflict is not silently ignored; escalate to a new reviewed ADR and modify the v2 documents if business policy changes.

### Explicit v1-to-v2 changes

| V1 gap/conflict | V2 resolution |
|---|---|
| `architecture.md` recommends NestJS vs stack document recommends Rust | Both used: NestJS gateway, Rust business core; worker shares Rust modules |
| One email per organisation and global uniqueness, no clear tenant policy | Globally unique email + at most one active/reserved org per account, **including tenant portal users**, and multiple capacities in same org |
| `organisation_owners` shows unique owner record but owner transfer history unclear | Owner appointments with one current appointment, controlled transfer and audited historical appointments |
| `membership_type` exclusive enum | Membership + capability rows; tenant/employee/person/occupant/lease participant are distinct |
| Billing schedule missing from v1 ERD | `billing_schedules`, run/items, invoice status events and tax/charge policy versions |
| Finance requires ledger but omitted supplier/AP, refunds, credit notes, bank import/matches | Add dedicated AP/bank/receipt/refund/credit/accounting source entities with atomic postings |
| Approval requests and clearance case described in PRD but missing as full entities | Versioned approval engine, clearance cases/units, inspections versions, settlement lines/disputes, separate statuses |
| File, workflow, notification, retention, outbox details incomplete | Add explicit private files, access logs, outbox/inbox, notifications, data subject requests and holds |
| Vercel/Render/Neon candidate region legality unresolved | Frankfurt is a *technical choice*; identifiable Ugandan production data blocked until legal adequacy/consent, vendor subprocessor and PDPO obligations are established |
| Tax, FX, cash, co-tenant liability not final | UGX-only, accrual, cash disabled, explicit liability shares, tax configured by qualified accountant; unknown tax blocks invoice issuance |

## Clear engineering go/no-go

**GO for synthetic-data P0 development** once the product owner adopts this v2 architecture.  
**NO-GO for live identifiable production data** until Phase 9 legal, privacy, tax, security and recovery sign-offs have been documented. The design intentionally does not pretend this non-technical gate can be certified by generating Markdown.

## Provider access note

Read-only connector access was checked for GitHub, Vercel, Render, Neon, Cloudflare (including R2), and Resend. GitHub repo-specific App installation returned none; the project repo does not exist yet in this design review. Auth0/other future providers need onboarding. **No infrastructure was created or altered.**
