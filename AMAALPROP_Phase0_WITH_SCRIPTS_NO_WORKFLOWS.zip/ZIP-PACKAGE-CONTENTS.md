# AMAALPROP Phase 0 — Source bundle (without workflow YAML)

- Unpack or import into **the existing AMAALPROP repository root**, not an extra `AMAALPROP/` folder.
- The package includes the complete Phase 0 application scaffold, requirements, contracts, infrastructure configuration, scripts, and importer tests.
- `scripts/import_release_zip.py` is the automatic ZIP importer (version 3).
- **No** `.github/workflows/*` files are packaged, by request. Install `.github/workflows/import-release-zip.yml` separately.
- Importer security policy protects its own script from replacement during ZIP imports; install or update that script independently for the first bootstrap.
- The source is Phase 0 scaffolding, not evidence of completed deployment.
