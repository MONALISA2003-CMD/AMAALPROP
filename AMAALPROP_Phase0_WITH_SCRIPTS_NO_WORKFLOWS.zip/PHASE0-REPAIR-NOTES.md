# AMAALPROP Phase 0 repair notes

This archive is a corrected local repository snapshot, **not** a remote deployment,
not proof that GitHub CI is green and not production-ready customer-data software.

## Specific changes from user-uploaded `AMAALPROP_phase0_source.zip`

- Corrected GitHub repo inventory: repository exists, `main` was documentation-only.
- Corrected Render inventory: no AMAALPROP services visible in accessible workspace;
  existing service IDs must be identified before any live write/sync.
- Confirmed Neon `amaalprop-v2-staging` / `staging` / `development` without modifying them.
- Restored original v1 document contents at repository root; removed duplicate archival subtree.
- Replaced persistent probe migration with rolled-back local SQL RLS harness.
- Added provisional OpenAPI, drift checker and offline repository doctor.
- Added Phase 0 runbook, provider inventory and evidence-based gate status.
- Refined local Compose and GitHub CI; external builds still require actual execution.
- Deferred Vercel binding; did not use any unrelated project's resource.
- Kept NestJS as public API edge, Rust as authoritative private core, Rust worker idle.

## Critical blockers

1. Render AMAALPROP services must be located in the correct workspace/account.
2. GitHub repo write permissions must be enabled; upload via PR and run actual CI.
3. Deploy genuine AMAALPROP Render services; verify the private Rust core call.
4. P1 will implement restricted Neon database role/wiring and domain migrations.

No existing Render, Neon, Vercel, Cloudflare or GitHub resources were changed.
