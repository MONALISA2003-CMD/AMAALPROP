# AMAALPROP — Canonical Logical ERD and Physical Integrity Specification v2

**Status:** Design-frozen for initial development; production tax, legal-retention and overseas-processing gates remain pending independent sign-off.  
**Supersedes:** AMAALPROP_ERD_Full.md v1 in conflicts; retains v1 property, tenant, maintenance and accounting foundations, and adds missing entities and constraints.  
**Companion specifications:** `identity-membership-v2.md`, `financial-workflows-v2.md`, `architecture-v2.md`, `hosting-data-protection-v2.md`.

## A. Global column/convention contract

1. All primary keys use `UUID`; externally exposed identifiers are opaque. Every organisation-owned business table **directly** includes `organisation_id UUID NOT NULL` and a composite unique key `(organisation_id,id)` where needed to support same-org FKs.
2. For tenant-owned foreign keys, prefer `FOREIGN KEY (organisation_id, parent_id) REFERENCES parent(organisation_id,id)`. For independent audit/referenced history, use `ON DELETE RESTRICT` rather than cascading financial/identity data.
3. Core tables contain `created_at timestamptz`, `updated_at timestamptz` for mutable entities, `created_by_membership_id` where relevant, and optimistic `row_version bigint` on workflow state. Append-only tables have `recorded_at`/event time and are never updated.
4. Monetary amounts use PostgreSQL `NUMERIC(20,4)`, currency `CHAR(3)`, business dates `DATE`, event time `TIMESTAMPTZ` (UTC storage); enforce ISO 4217 scale: for UGX, `amount = trunc(amount)`; amounts positive unless explicit debit/credit pair. Integer-like identifiers such as receipts are allocated using an organisation-scoped DB sequence counter transaction.
5. Organisation-level operational audit and financial posting **must** be done by Rust using RLS-enabled transactions. A separate global identity context handles `user_accounts` without exposing other organisations' details. Runtime DB role has no `BYPASSRLS`; tests run as runtime role.
6. Enumerated state transitions live in domain code with DB check constraints and an append-only event log. Do not implement 'any status can become any other status'.
7. `document_files`/`stored_files` metadata are in PostgreSQL; binary content lives in private object storage. Secrets and raw identification numbers are encrypted or tokenised and excluded from logs.
8. Use soft deactivation + historical revision records for business facts; never soft-delete financial records in a way that changes reports or permits disappearing audit evidence.
9. High-volume events/attempts have `(organisation_id, created_at)` indexes; financial source tables carry unique business/idempotency keys. Deny RLS if tenant context is missing.

## B. Canonical relationship map

```mermaid
erDiagram
 USER_ACCOUNTS ||--o{ EXTERNAL_IDENTITIES : has
 USER_ACCOUNTS ||--o{ ORGANISATION_MEMBERSHIPS : historical
 PROPERTY_ORGANISATIONS ||--o{ ORGANISATION_MEMBERSHIPS : authorises
 ORGANISATION_MEMBERSHIPS ||--o{ MEMBERSHIP_CAPABILITIES : has
 PROPERTY_ORGANISATIONS ||--o{ OWNER_APPOINTMENTS : has_history
 ORGANISATION_MEMBERSHIPS ||--o{ TENANT_PORTAL_GRANTS : may_use
 PROPERTY_ORGANISATIONS ||--o{ PROPERTIES : owns
 PROPERTIES ||--o{ RENTABLE_UNITS : holds
 RENTABLE_UNITS ||--o{ LEASE_UNITS : assigned
 LEASES ||--o{ LEASE_UNITS : includes
 TENANT_PARTIES ||--o{ LEASE_PARTICIPANTS : participates
 LEASES ||--o{ LEASE_PARTICIPANTS : has
 LEASES ||--o{ BILLING_SCHEDULES : generates
 BILLING_SCHEDULES ||--o{ BILLING_RUN_ITEMS : tracks
 BILLING_RUN_ITEMS ||--o| INVOICES : creates
 INVOICES ||--|{ INVOICE_LINES : lists
 INVOICES ||--o{ CREDIT_NOTES : adjusted_by
 PAYMENT_SUBMISSIONS ||--o| PAYMENTS : verified_into
 PAYMENTS ||--o{ PAYMENT_ALLOCATIONS : allocates
 PAYMENTS ||--o| RECEIPTS : receipted
 PAYMENTS ||--o{ REFUND_REQUESTS : may_refund
 REFUND_REQUESTS ||--o{ REFUND_DISBURSEMENTS : completed_by
 BANK_STATEMENT_IMPORTS ||--|{ BANK_STATEMENT_LINES : contains
 BANK_RECONCILIATIONS ||--o{ BANK_RECONCILIATION_MATCHES : records
 JOURNAL_ENTRIES ||--|{ JOURNAL_LINES : balanced_by
 JOURNAL_ENTRIES ||--o{ JOURNAL_REVERSAL_LINKS : reversed_by
 SUPPLIERS ||--o{ SUPPLIER_BILLS : bills
 SUPPLIER_BILLS ||--o{ SUPPLIER_BILL_LINES : contains
 MOVE_OUT_REQUESTS ||--o| CLEARANCE_CASES : opens
 CLEARANCE_CASES ||--o{ INSPECTIONS : has
 CLEARANCE_CASES ||--o{ DEPOSIT_SETTLEMENTS : proposes
 APPROVAL_POLICIES ||--o{ APPROVAL_POLICY_VERSIONS : versions
 APPROVAL_REQUESTS ||--o{ APPROVAL_REQUEST_STEPS : requires
 APPROVAL_REQUEST_STEPS ||--o{ APPROVAL_DECISIONS : decided_by
 WORKFLOW_INSTANCES ||--o{ WORKFLOW_TRANSITIONS : tracks
 DOMAIN_OUTBOX ||--o{ OUTBOX_DELIVERY_ATTEMPTS : attempted
```

**Important override to v1 ERD diagram:** Lease-to-unit is `leases -> lease_units -> rentable_units` (not a single `rentable_unit_id` on `leases`). One lease may have multiple units and multiple tenant parties. Inspection and clearance are per unit where necessary, with a clearance case summarising the whole move-out.

## C. Full entity inventory (v1 retained + v2 additions)

Legend: **E** = present in v1 ERD; **N** = new table; **R** = v1 table requiring revised constraints/fields. This is the complete v2 domain catalog; explicit v2 definitions below override any v1 contradictions.

| Domain | Tables | Rule |
|---|---|---|
| Global IAM | **R** `user_accounts`, **N** `external_identities`, **N** `identity_invitations`, **N** `identity_email_change_requests`, **N** `identity_email_reservations`, **N** `security_events`, **N** `user_session_revocations` | Global unique verified email; account status and session revoke |
| Organisation and RBAC | **E** `property_organisations`; **R** `organisation_owners` (historical replaced by `organisation_owner_appointments`), `organisation_memberships`, `roles`, `role_permissions`, `user_role_assignments`, `reporting_relationships`, `scope_assignments`; **N** `membership_capabilities`, `employee_profiles`, `organisation_owner_appointments`, `organisation_transfer_requests`, `approval_delegations`, `membership_events` | Exactly one current owner; max one live org per login; scope ≠ hierarchy |
| Property | **E** `portfolios`, `properties`, `buildings`, `property_levels`, `unit_types`, `rentable_units`, `unit_occupancy_policies`, `unit_features`, `unit_feature_assignments`; **N** `unit_occupancy_policy_versions`, `unit_occupancy_events` | Optional building/level; custom unit codes; no overlap/over-capacity |
| Tenant and lease | **E** `tenant_parties`, `tenant_persons`, `tenant_identification_documents`, `tenant_contacts`, `tenant_documents`, `leases`, `lease_units`, `lease_participants`, `lease_charge_rules`, `lease_documents`, `lease_events`; **N** `occupants`, `tenant_portal_grants`, `lease_amendments`, `lease_renewals`, `lease_liability_shares`, `lease_occupancy_events`, `lease_notice_events` | Tenant profile, legal party, person, occupant and login distinct; liability explicitly allocated |
| Payment instructions/collections | **R** `payment_instructions`, `payment_instruction_scopes`, `payment_submissions`, `payments`, `payment_allocations`, `payment_events`; **N** `payment_verification_evidence`, `payment_submission_events`, `unapplied_receipt_movements`, `receipts`, `receipt_sequences`, `refund_requests`, `refund_approvals`, `refund_disbursements`, `payment_reversal_requests` | Evidence before verification; receipt only after posting; refunds traceable |
| Billing | **R** `invoices`, `invoice_lines`; **N** `charge_types`, `rent_policies`, `billing_schedules`, `billing_runs`, `billing_run_items`, `invoice_status_events`, `credit_notes`, `credit_note_lines`, `tax_codes`, `tax_treatments`, `financial_health_policy_versions` | Scheduled invoice idempotency; issued invoices adjusted via credit note |
| Accounting | **R** `accounts`, `accounting_periods`, `journal_entries`, `journal_lines`, `journal_reversal_links`, `expenses`; **N** `organisation_accounting_policies`, `posting_rules`, `journal_source_links`, `accounting_period_events`, `accounting_closure_checklists`, `currency_precision`, `currency_exchange_rate_snapshots`, `organisation_financial_sequences`, `account_balance_snapshots` | Posted ledger immutable; debit=credit; locked periods; source uniqueness |
| Suppliers and reconciliation | **N** `suppliers`, `supplier_contacts`, `supplier_bills`, `supplier_bill_lines`, `supplier_disbursements`, `bank_accounts`, `bank_statement_imports`, `bank_statement_lines`, `bank_reconciliations`, `bank_reconciliation_matches`, `bank_reconciliation_events` | Supplier AP and bank proof distinct from tenant submissions |
| Financial-health/deposit | **E** `tenant_payment_policies`, `tenant_financial_status_history`, `deposit_transactions`; **N** `deposit_accounts`, `deposit_settlements`, `deposit_settlement_lines`, `tenant_credit_balances_cache` | Deposit is liability; financial standing derived; caches not authoritative |
| Maintenance | **E** `maintenance_requests`, `work_orders`, `work_order_events`; **N** `work_order_assignments`, `work_order_cost_lines`, `maintenance_approvals` | Scope checks and actual/estimated cost separation |
| Inspections and clearance | **E** `move_out_requests`, `inspection_templates`, `inspection_template_items`, `inspections`, `inspection_items`, `inspection_evidence`, `clearance_steps`, `clearance_decisions`; **N** `inspection_template_versions`, `clearance_cases`, `clearance_case_units`, `key_handover_records`, `clearance_status_events`, `settlement_disputes` | Physical/financial/legal statuses separate; inspection snapshot immutable |
| Approval engine | **N** `approval_policies`, `approval_policy_versions`, `approval_policy_steps`, `approval_requests`, `approval_request_steps`, `approval_decisions`, `approval_delegations`, `approval_escalations` | Version-bound, independent maker/checker, delegation limited |
| Workflow/outbox | **N** `workflow_definitions`, `workflow_instances`, `workflow_transitions`, `domain_outbox`, `outbox_delivery_attempts`, `inbox_deduplication`, `scheduled_jobs`, `idempotency_keys` | Atomic outbox, idempotent consumers, audited state machine |
| Documents/comms/audit | **E** `notifications`, `audit_events`, `stored_files`; **N** `stored_file_access_events`, `file_upload_intents`, `file_scans`, `notification_templates`, `notification_attempts`, `communication_threads`, `communication_events`, `document_retention_assignments`, `report_exports` | Private files, queue delivery, scoped exports, append-only audit |
| Governance | **N** `retention_policies`, `legal_holds`, `data_subject_requests`, `erasure_jobs`, `consent_records`, `data_processing_purposes`, `processor_register`, `breach_incidents` | Retention, rights, hold, DPIA and breach audit |
| SaaS commercial (defer) | **N/Later** `subscription_plans`, `organisation_subscriptions`, `subscription_invoices`, `entitlement_limits` | SaaS charges separated from landlord rent ledger |
| AI (defer) | **N/Later** `ai_jobs`, `document_extraction_reviews`, `ai_embeddings`, `ai_access_audits` | Only permission-filtered and optionally enabled; no automated finance |

## D. Identity/organisation physical changes (mandatory Phase 1)

`user_accounts`: `id`, `email`, `normalised_email UQ`, `email_verified_at`, `status`, `created_at`, `updated_at`; **no organisation ID**. `external_identities`: `user_account_id`, `(issuer,subject) UQ`, `linked_at`, `last_verified_at`.

`organisation_memberships`: `id`, `organisation_id`, `user_account_id`, `status` (`invited`,`pending_approval`,`active`,`suspended`,`revoked`,`ended`), `valid_from`, `valid_until`, actor refs and timestamps. `UQ(user_account_id)` **partial** for live/reserved states. Do not interpret a historical transfer as permission in the old organisation. `membership_capabilities`: one row per `(organisation_id,membership_id,capability)` and date interval.

`organisation_owner_appointments`: `id`, `organisation_id`, `membership_id`, `appointed_at`, `ended_at`, `transfer_request_id`, `approved_by`; `UQ(organisation_id) WHERE ended_at IS NULL`; active org must reference its current active owner. `organisation_transfer_requests`: `from_org_id`, `to_org_id`, `user_account_id`, `status`, `initiator`, `old_membership_id`, `new_membership_id`, `approver`, effective dates and audit. Transfer is serialized under `user_accounts FOR UPDATE`.

`identity_invitations`: `organisation_id`, `canonical_email`, `token_hash`, `issued_by_membership_id`, `capability`, `expires_at`, `verified_at`, `approved_at`, `status`. For unknown email, reserve canonical email in `identity_email_reservations` until expiry; no token reuse. Do not block tenant registration just because portal activation is unavailable.

`tenant_portal_grants`: org/membership and tenant person/party refs, explicit `access_type` and grant scope, approved by, date bounds; share only classified lease facts, never default all co-tenant data. Scope tables use typed foreign keys or a DB-verifiable owner lookup.

## E. Financial entity additions (mandatory before finance migration)

| Table | Required fields / constraints |
|---|---|
| `organisation_accounting_policies` | org PK, `base_currency`, `accounting_basis='accrual'`, posting rules version, `fiscal_year_start`, `allow_multi_currency=false`, `approved_by`, `effective_at` |
| `currency_precision` | ISO code PK, scale, authoritative source/version; UGX scale=0 |
| `currency_exchange_rate_snapshots` | org, source/quote currency, rate, provider, valid time, source reference, immutable; **FX disabled in MVP** |
| `charge_types` | org/code UQ, description, default revenue/receivable/liability account mapping, active state |
| `rent_policies` | org, scope, billing freq, due-date rule, grace days, reminder policy, proration and version; amendments effective prospectively |
| `billing_schedules` | org, lease, charge type, amount/currency, frequency, start/end, due rule, advance/arrears, status, version, actor; one effective schedule-version per interval |
| `billing_runs` | org, scheduled cycle, run key UQ, started/completed, scheduler version and error/status |
| `billing_run_items` | org, run, schedule, `cycle_key`, invoice optional, status, `UQ(org,schedule_id,cycle_key,policy_version)` |
| `invoice_status_events` | org, invoice, old/new status, time, actor, reason; append-only |
| `credit_notes` | org, invoice, number UQ/org, reason, subtotal/tax/total/currency, status, issued_by, issued_at, journal_source; cannot exceed eligible invoice remainder |
| `credit_note_lines` | org, credit_note, invoice_line optional, quantity/amount/tax/account mapping, reason |
| `tax_codes` | org, code, tax treatment classification, country, effective dates; no rate silently defaulted for unknown case |
| `tax_treatments` | org, charge_type and/or invoice_line, tax_code, rate/effective/version, reviewed_by; block taxable invoice issue until configured |
| `payment_verification_evidence` | org, submission, evidence type (`statement_line`,`bank_portal_observation`,`mobile_money_record`,`other`), file/statement FK, channel, verified_source_ref, review notes, evidence hash, reviewer |
| `receipts` | org, `payment_id UQ`, receipt_number `UQ(org,number)`, issued timestamp, immutable payload snapshot, file FK, issuer, source journal ID; void state derived from reversal |
| `receipt_sequences` | `(organisation_id,fiscal_period)` PK, next integer, transactionally locked |
| `unapplied_receipt_movements` | org, payment, tenant party, amount/currency, `kind` (`credit`,`allocated`,`refunded`,`deposit_transfer`,`reversed`), journal ID; credit liability derived |
| `refund_requests` | org, payment/source liability, beneficiary, bank destination encrypted/masked, reason, amount/currency, requester, `status` (`draft`,`submitted`,`approved`,`rejected`,`processing`,`paid`,`failed`,`cancelled`), idempotency key |
| `refund_approvals` | org, refund request, approval request ID, approved by, amount/version/snapshot, timestamp, actor distinct from maker |
| `refund_disbursements` | org, refund, external confirmation, date, amount/currency, bank statement line optional, confirmed_by, `journal_entry_id UQ`, status, `UQ(org,external_ref,channel)` where provided |
| `payment_reversal_requests` | org, payment, reason, actor, approval request, resulting reversal journal and event; cannot edit original payment/journal |
| `journal_source_links` | org, `source_module`, `source_id`, `posting_action`, version, journal entry, `UQ(org,source_module,source_id,posting_action,version)` |
| `accounting_period_events` | org, period, action (`closed`,`reopened`), actor, independent approver, reason, before/after state, timestamp |
| `accounting_closure_checklists` | org, period, checklist item, completion and evidence, approved_by |
| `organisation_financial_sequences` | org, sequence_code, fiscal_period, `next_number`; `UQ(org,sequence_code,fiscal_period)` |
| `suppliers` | org, name, supplier type, registration ID optional, contact, payment details encrypted, status |
| `supplier_bills` | org, supplier, bill number/vendor ref, invoice date/due date, amount/currency, `status`, approval request, payable journal, `UQ(org,supplier_id,vendor_reference)` if known |
| `supplier_bill_lines` | org, bill, expense account, property/work order allocation, quantity, amount, tax treatment, description |
| `supplier_disbursements` | org, bill, amount, destination, approval and bank confirmation, journal entry, idempotency key |
| `bank_accounts` | org, account code, currency, bank, encrypted number, owner, GL account FK, status; active payment instruction references destination when applicable |
| `bank_statement_imports` | org, bank account, file/checksum, from/to, imported_by/at, status, `UQ(org,bank_account_id,file_checksum)` |
| `bank_statement_lines` | org, import, bank account, transaction date, posting date, amount signed and currency, reference, payer, account balance optional, stable bank-line fingerprint `UQ(org,bank_account_id,source_fingerprint)` |
| `bank_reconciliations` | org, bank account, statement period, opened_by, approved_by, status, opening/closing statement and ledger balances, reviewed_at |
| `bank_reconciliation_matches` | org, reconciliation, statement line, journal/payment/disbursement source, amount, status, matched_by, `UQ(org,statement_line_id)` for a final match; partial matches use a separate allocation policy |
| `bank_reconciliation_events` | org, reconciliation, event, actor, timestamp, justification; append-only |
| `deposit_accounts` | org, lease, tenant party, ledger liability account, currency, linked original verified collection |
| `deposit_settlements` | org, clearance_case, lease/party, financial snapshot, prepared_by, reviewed_by, approved_by, status, version, resulting refund/credit transactions |
| `deposit_settlement_lines` | org, settlement, component (`rent_arrears`,`utilities`,`damage`,`refund`,`other`), amount, evidence, disputed flag, invoice/damage charge source, approved-by |

**Accounting policy:** UGX-only first release, accrual base, no implicit tax rate, no multi-currency journals, refundable deposit is liability, verified collections first credit unapplied tenant receipts then allocate/apply through separate balanced journals. This replaces the v1 shorthand that assumes verified rent cash directly credits receivables.

## F. Workflow/entity additions

| Table | Required fields / constraints |
|---|---|
| `approval_policies` | org, workflow/action code, scope owner, status; stable policy identity |
| `approval_policy_versions` | org, policy, version UQ, effective_from/until, conditions JSON validated against schema, maker-checker configuration, published by/at; immutable once used |
| `approval_policy_steps` | org, policy_version, seq, role/permission, required count, parallel/sequential mode, threshold, escalation window |
| `approval_requests` | org, policy_version, source type/id, requested action, requester, amount/currency snapshot, status, submitted_at, due_at, `source_row_version`, command ID |
| `approval_request_steps` | org, request, step definition, assigned approver/group, status, started/completed, sequence, version |
| `approval_decisions` | org, request_step, actor, decision, comment/reason, evidence, timestamp, delegation snapshot; immutable; requester cannot approve own controlled action |
| `approval_delegations` | org, grantor, grantee, permission, scope, max amount, valid interval, approved_at, revoked_at; cannot exceed grantor authority |
| `approval_escalations` | org, request step, escalated_to, reason, event time, status |
| `workflow_definitions` | globally versioned state-machine schema for org-owned domain aggregate types; programmatic, validated transitions |
| `workflow_instances` | org, workflow type/version, source type/id, status, current state, `row_version` |
| `workflow_transitions` | org, instance, command/event ID UQ, from/to state, actor, timestamp, reason, metadata redacted; append-only |
| `clearance_cases` | org, move_out_request, lease, assigned inspector/manager/finance/final approver, physical status, financial status, handover status, legal lease status **separate**, case status, created/closed |
| `clearance_case_units` | org, clearance case, unit, required inspection, returned key count, condition/handover status; `UQ(org,case_id,unit_id)` |
| `inspection_template_versions` | org, inspection template, version number, published time, immutable item snapshot/checklist hash |
| `key_handover_records` | org, clearance_case/unit, handed_by/received_by, keys/cards counts, time, evidence, notes |
| `clearance_status_events` | org, case, old/new state per dimension, actor, time, reason; immutable |
| `settlement_disputes` | org, settlement line, raised_by, basis, evidence, status, resolution actor/time; **unresolved disputed deductions cannot silently proceed as agreed** |
| `work_order_assignments` | org, work_order, employee/contractor, scope, assigned/accepted/completed, status |
| `work_order_cost_lines` | org, work_order, supplier bill optional, expected cost, actual cost, currency, category, approval request, notes |
| `file_upload_intents` | org, actor, subject type/id, allowed type/size, object key, expiry, malware scan state and checksum |
| `file_scans` | org, file FK, scanner, result (`pending`,`clean`,`blocked`,`unavailable`), scanning timestamp, details redacted |
| `stored_file_access_events` | org, file FK, actor, permission checked, time, purpose, outcome, IP redacted |
| `notification_templates` | org or system template, code, version, channel, locale, approved, active, content source |
| `notification_attempts` | org, notification, provider, provider event ID, status, attempt count, error category, sent/delivered timestamps |
| `communication_threads`, `communication_events` | org and entity/recipient scope, direction, channel, actor, body reference/redacted summary, provider link, timestamp |
| `report_exports` | org, requesting membership, scope/filter snapshot, status, file FK, expiry, audit correlation |
| `domain_outbox` | org, aggregate type/id, event type+version, payload (minimal), dedupe key UQ, published_at null, attempt count, next_attempt_at |
| `outbox_delivery_attempts` | org, outbox event, worker/version, status, attempt time, failure category |
| `inbox_deduplication` | org, consumer, event ID, applied timestamp, `UQ(org,consumer,event_id)` |
| `scheduled_jobs` | org, job key, type, due time, status, schedule version, `UQ(org,job_key)` |
| `idempotency_keys` | org, principal/route, client key, request digest, response ref/status, expires_at, `UQ(org,principal,route,client_key)` |
| `retention_policies`, `document_retention_assignments`, `legal_holds`, `data_subject_requests`, `erasure_jobs`, `consent_records`, `data_processing_purposes`, `processor_register`, `breach_incidents` | purpose/category, org where applicable, jurisdiction/policy version, actor, due/hold/expiry, status, auditable decisions, legal basis and evidence references |

## G. State machines and transactions

| Aggregate | Valid high-level transitions | Invariant |
|---|---|---|
| Organisation | pending verification -> pending review -> active -> suspended/closed | Exactly one active designated owner |
| Membership | invited -> pending approval -> active -> suspended/revoked/ended | No two simultaneously live organisations for one identity |
| Lease | draft -> review -> approved -> active -> notice/terminated/expired | Unit overlap/capacity checked atomically; termination independent from clearance |
| Invoice | draft -> issued -> part_paid/paid/overdue -> adjusted/credited | Issue posts accrual; credit note rather than mutation |
| Submission | submitted -> under_review -> verified/rejected/disputed/duplicate/cancelled | No verified state without separate financial evidence and posting |
| Refund | draft -> submitted -> approved -> processing -> paid/failed | Separate maker/approver/confirmer; post only on confirmed disbursement |
| Period | open -> closing -> closed; closed -> reopened only on approved exception | No backdated posting into closed period |
| Maintenance | reported -> triaged -> approved/assigned -> in_progress -> completed -> verified/closed | Property/contractor scope enforced |
| Clearance | submitted -> inspection -> manager_verification -> financial_review -> final_approval -> handover/closed | Physical, financial and legal statuses independent |
| Approval request | pending -> in_review -> approved/rejected/returned/expired/cancelled | Immutable decisions and policy version |

**Concurrency and idempotency:** Use explicit `SELECT ... FOR UPDATE` on subject payment/invoice/lease/period rows (or exclusion/unique constraints); bind command idempotency key, source version and journal source uniqueness in one DB transaction. Failed commands must not leave a posted journal without matching domain record, or vice versa.

## H. PostgreSQL guardrail examples (implement and test in migrations)

```sql
-- Illustrative, not the entire production migration.
CREATE UNIQUE INDEX uq_user_email ON user_accounts (normalised_email);
CREATE UNIQUE INDEX uq_one_live_org_per_account
  ON organisation_memberships (user_account_id)
  WHERE status IN ('invited','pending_approval','active','suspended');
CREATE UNIQUE INDEX uq_one_current_owner
  ON organisation_owner_appointments (organisation_id)
  WHERE ended_at IS NULL;
CREATE UNIQUE INDEX uq_invoice_cycle
  ON billing_run_items (organisation_id, billing_schedule_id, cycle_key, policy_version);
CREATE UNIQUE INDEX uq_journal_source_action
  ON journal_source_links (organisation_id, source_module, source_id, posting_action, source_version);
-- For every org-owned table:
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices FORCE ROW LEVEL SECURITY;
CREATE POLICY invoices_org_policy ON invoices
 USING (organisation_id = nullif(current_setting('app.organisation_id', true), '')::uuid)
 WITH CHECK (organisation_id = nullif(current_setting('app.organisation_id', true), '')::uuid);
-- Production migrations must additionally define runtime roles, composite FKs,
-- financial posting triggers, immutable journal guards, indexes and policy tests.
```

**Do not rely only on an application-level debit=credit test.** The `post_journal` Rust transaction must lock the journal/period, re-validate every line and account, compute sum(debit)-sum(credit), ensure at least two nonzero lines and zero difference at currency precision, then atomically mark posted; a DB trigger/constraint protects against direct mutation or incorrect posting, including retries. Posted records remain immutable; journal reversals are new entries.

## I. Critical counterexamples (must fail)

1. Cross-org composite FK or RLS access via malicious organisation/parent ID; private download and exports likewise.
2. One email reserved/invited/active in organisation A cannot activate in B concurrently; old historical records remain immutable.
3. Invoice job execution twice for same schedule/cycle; duplicate journal/source; double payment verification; two refund disbursements with same confirmation.
4. Zero-line, one-line, unbalanced, wrong-currency, nonzero UGX fraction, out-of-period or mutable posted journal.
5. Deposit credited as income without explicit authorised settlement; unpaid/overpaid tenant balance misrepresented.
6. Refund authorised by requester, unconfirmed disbursement journal, unapproved supplier bill paid.
7. Caretaker final-approves clearance; unverified inspection is treated as approved; a landlord closes legal lease solely because a clearance case is financially unresolved.
8. Expired file URL, foreign tenant's identity files, reused approval decision, unsigned internal delegation and request with no RLS tenant context.

## J. Migration ownership map

- Phase 0: SQL role/RLS harness, enum/decimal strategy, bootstrap global identity tables (no live customer data).
- Phase 1: `user_accounts`, `external_identities`, memberships/capabilities, invitations, roles, scoped access, ownership and audit.
- Phase 2: property and occupancy inventory.
- Phase 3: tenant, lease, portal grants, approvals and workflow engine foundations.
- Phase 4: accounting policies/periods, accounts, source links, immutable journals, invoice/credit/deposit ledger primitives.
- Phase 5: billing schedules/runs, invoices, payments, evidence, receipt, refund and reconciliation tables.
- Phase 6: suppliers/AP, maintenance, inspection versions, clearance case/units and settlements.
- Phase 7: notifications, document operations, reports, retention/rights and exports.
- Phase 8: optional AI schema (strict tenant-scoped retrieval).
- Phase 9: migration freeze, independent data/finance/security review, production gating.

## K. What is deliberately NOT declared a legal fact

Ugandan VAT/withholding treatment, retention periods, deposit-forfeiture law, accountant-required approval thresholds and overseas-hosting compliance require jurisdiction-specific professional review. The schema is designed to implement approved policy versions without re-engineering the core model; **it does not auto-approve undefined financial/legal treatments**.
