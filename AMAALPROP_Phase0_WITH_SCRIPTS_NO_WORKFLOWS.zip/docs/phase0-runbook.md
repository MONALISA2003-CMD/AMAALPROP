# AMAALPROP Phase 0 runbook — build, verify, connect safely

**Scope:** AMAALPROP only. Do not modify other GitHub repositories, Render services,
Vercel projects, Neon projects, domains or Cloudflare buckets.

## 1. Verify repository state

Existing GitHub repo: `MONALISA2003-CMD/AMAALPROP` (`main`, originally design-only).
Open a **new PR branch** containing this repaired scaffold; preserve all original v1 docs.
The repo is public as observed, so no secrets or real tenant records may be committed.
Confirm GitHub App repository-scoped write permissions before automation attempts.

## 2. Local reproducible tests

1. Install pinned Node/pnpm and Rust components from manifest files.
2. `node scripts/doctor.mjs && node scripts/verify-openapi.mjs`
3. `pnpm install --frozen-lockfile && pnpm build && pnpm typecheck`
4. `cargo fmt --all --check && cargo clippy --locked --all-targets -- -D warnings`
5. `cargo test --locked && cargo build --locked`
6. `cp .env.example .env`; generate **two distinct random 32+ character** secrets.
7. `docker compose up --build` then, in another shell, `pnpm run test:boundary`.
8. `TEST_DATABASE_URL='postgresql://postgres:local-synthetic-only@127.0.0.1:5432/amaalprop_test' bash scripts/verify-rls.sh`
9. `docker compose down -v` when finished; verify tests exit cleanly and no roles/fixtures persist.

**Do not run `verify-rls.sh` against Neon.** It will refuse non-local URLs.

## 3. Render: resolve workspace identity BEFORE using Blueprint

The accessible Render workspace service listing did not contain AMAALPROP services.
Do not treat another service with a similar brand prefix as AMAALPROP.
Obtain the **exact workspace and service IDs** from Render service settings for:
`amaalprop-v2-gateway` (web), `amaalprop-v2-core` (private service),
`amaalprop-v2-worker` (background worker), or the actual names if different.

When located, compare existing service type, region, root dir, Dockerfile path,
repository/branch, environment and billing plan against `render.yaml`.
An existing service can be adopted by Blueprint name; **review the plan** because
Blueprint syncing may change existing settings. Never auto-approve a destructive plan.

Recommended private wiring once service IDs are verified:
- Gateway `CORE_HOST`: `fromService: {name: amaalprop-v2-core, type: pserv, property: host}`
- Core and gateway `PORT`: 10001/10000 respectively
- Core has generated `INTERNAL_SIGNING_SECRET`; gateway references **that service's** value
- Gateway has its *own* generated `STAGING_SMOKE_TOKEN` (never reused as a login token)
- Worker has no database credentials or business jobs until P1/P4.
- `DATA_MODE=synthetic` for all Phase 0 processes.

Smoke: public `GET /api/v1/health` returns synthetic; authenticated staging
operator `GET /api/v1/core-health` succeeds; invalid tokens rejected; core must
have **no public URL**, and a browser cannot reach core directly.

## 4. Neon: verified project but deliberately not bound to deployed services yet

- Neon project: `amaalprop-v2-staging`, project ID `royal-flower-91615135`, Frankfurt.
- `staging` default branch `br-steep-block-b9j1xe3k`, database `amaalprop`.
- `development` branch `br-still-cloud-b9ox6qx0`.
- Staging contains no app tables and currently has only the `amaalprop_migrator` role; development has an older synthetic test table and both `amaalprop_runtime` and `amaalprop_migrator` roles.
- Separate migrator and restricted runtime roles; table-owner/superuser credentials
  must not be used by public-facing gateway or browser.
- Do not copy development fixtures into staging or deploy schema from the old ERD.
- P1 must implement Rust-owned SQLx connection pool, transaction-local RLS context,
  composite FK constraints and real org membership; only then grant runtime DB access.
- Neon connection strings go into Render **secret environment variables**, never Git.

## 5. Vercel, Cloudflare and external integrations

- Vercel does **not** need linking to pass backend/local Phase 0; keep web as build-only.
- No verified AMAALPROP domain/R2 bucket should be reused from unrelated projects.
- Auth0, Resend and monitoring should be configured in their own later phases,
  not borrowed from other apps without explicit AMAALPROP-specific confirmation.
- Only synthetic test data is allowed. Live deployment/compliance = later P9 approval.

## 6. Definition of done

After GitHub PR+CI pass, run the deployed gateway private-core probe, verify no
public core route, record Render service IDs, and attach environment/branch evidence.
Only then call P0 **complete**; otherwise keep it **partial**.
