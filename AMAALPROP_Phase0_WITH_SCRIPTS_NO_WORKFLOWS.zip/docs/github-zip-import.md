# AMAALPROP — Automatic ZIP import (v3)

This source release intentionally **does not contain GitHub Actions workflow files**. Install the workflow separately at `.github/workflows/import-release-zip.yml`.

The importer is included here at `scripts/import_release_zip.py`, along with its offline tests at `tests/importer/test_import_release_zip.py`. On initial setup, commit the importer script and workflow to the repository **before** uploading the release ZIP. To protect the import process, the running importer never overwrites its own script or workflow with ZIP contents. Updating the importer in the future requires a separate reviewed change.

After one-time installation, committing any ZIP anywhere in the repository triggers the external workflow. It detects ZIP files, checks paths and size limits, flattens accidental top-level wrapper folders, reconciles identical documents, preserves files omitted from partial updates, deletes processed archives and commits the clean result. Conflicting versions fail without choosing a winner.

The workflow does not trigger on GitHub Release assets, issue attachments, or archives uploaded outside the Git repository. Existing branch protection must allow the chosen automation strategy. Do not disable required branch protection to enable an importer.

Run the offline importer tests with `python -m unittest discover -s tests/importer -p 'test_*.py'`.
