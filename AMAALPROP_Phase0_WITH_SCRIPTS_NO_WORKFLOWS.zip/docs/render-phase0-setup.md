# Render Phase 0 — AMAALPROP setup and pending approval

The repository `render.yaml` describes only three synthetic, non-production services in Frankfurt:

| Service | Type | Render plan | Purpose |
| --- | --- | --- | --- |
| `amaalprop-v2-gateway` | public web | `free` | NestJS gateway; `/api/v1/health` |
| `amaalprop-v2-core` | private service (`pserv`) | `0.5c-512mb` | Internal Rust Axum core; signed gateway probes |
| `amaalprop-v2-worker` | worker | `0.5c-512mb` | Rust idle background process; no real jobs |

The private core and worker plans are listed by Render at **$7/month each** (approx. **$14/month total** before any additional charges). The proposed YAML disables automatic deployments. Its secrets use Render-generated values, not source-control values. There is no `DATABASE_URL` in the Blueprint until restricted Neon credentials and tenancy policies are ready. `DATA_MODE=synthetic` is required by every backend process.

**Live status on 2026-11-14:** The only accessible Render workspace is called `My Workspace`; no AMAALPROP services were found in its service list. **No Render services were created or charged by this work.** Creation requires (1) user's confirmation of the target workspace and paid plans, (2) a GitHub repository containing the source and `render.yaml`, and (3) reviewing and approving the first Blueprint plan. GitHub connector currently can read AMAALPROP but cannot write (403), so the source cannot be published through this integration without repository authorisation.

When ready: publish source via the ZIP-import PR; create the Render Blueprint from the AMAALPROP repo (main branch, `render.yaml`, resource handling `create_new`); review projected names/plans; approve only after explicit user approval; verify public health and signed private service boundary; keep Neon staging safe and untouched until its own migration gate.

**Vercel:** Not needed to complete this synthetic gateway/core/worker deployment. Connect it in its planned frontend integration step.
