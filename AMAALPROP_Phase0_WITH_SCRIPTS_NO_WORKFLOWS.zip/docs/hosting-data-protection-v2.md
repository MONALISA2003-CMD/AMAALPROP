# AMAALPROP — Hosting and Uganda Data Protection Decision v2

**Status:** Technical topology selected; **production use of identifiable Ugandan customer data NOT YET AUTHORISED**.  
**Verified against official/primary public materials on:** 13 November 2026.  
**Not legal advice.** Final legal conclusions, registration and contracting require a qualified Ugandan data-protection adviser and the responsible business representative.

## Hosting decision (locked for engineering builds)

| Layer | Product / proposed location | Engineering control |
|---|---|---|
| Source control | GitHub private monorepo | No customer data in repository/issues/CI artifacts; least-privilege Actions and secrets |
| Public UI | Vercel Next.js | Static assets global; if Functions used, configure `fra1` and `no-store` private data; audit CDN/log/failover locations |
| Public API | NestJS on Render **Frankfurt** | Cloudflare WAF/HTTPS, app JWT validation, no direct DB access |
| Internal core | Rust Axum **private Render service, Frankfurt** | Render private network, signed service assertions, only trusted Nest/worker callers |
| Worker | Rust **Render background worker, Frankfurt** | Tenant context on every job, no inbound public listener |
| Database | **Separate** AMAALPROP Neon PostgreSQL project, Frankfurt `aws-eu-central-1` candidate | Runtime/migration separation, RLS, backups/PITR, restricted roles, restore drills |
| Documents/evidence | **New** Cloudflare R2 bucket restricted to `eu` jurisdiction | S3-compatible private access, no public asset URL; encryption, scan, signed short-lived access, retention |
| DNS & perimeter | Cloudflare | Proxy public API after custom-domain validation; no caching of auth, invoice, reports or files; verify origin-bypass mitigation |
| Identity | Auth0 single OIDC tenant, configured for applicable data-processing commitments | Verify identity-region, logs, support, backup, subprocessor transfers before onboarding real users |
| Email | Resend transactional email adapter (existing connector read-only access confirmed) | Dedicated verified sender/domain for AMAALPROP, protect invite token links, review email data/storage jurisdiction |
| SMS/AI/error monitoring | **Not yet selected/contracted for AMAALPROP** | Feature off until provider region, contract, credentials and DPA evaluated |

**Important nuances:** Vercel's global CDN, identity provider, Cloudflare edge, email routing, support, analytics and backups may involve processing outside the intended primary compute region. A Frankfurt database is **not** a promise of EU-only processing for the whole system. An R2 location hint is **not** a residency guarantee; select `eu` **jurisdiction** at bucket creation and verify resulting bucket details. Render services must use the **same workspace and region** for private networking. Never reuse another product's existing database/project/bucket without explicit assignment.

## Uganda law: what the public sources say

1. **Data Protection and Privacy Act, 2019, s.19** establishes conditions for data controllers/processors based in Uganda to process or store personal data outside Uganda: adequate protection at least equivalent to the Act **or** data-subject consent.
2. **Data Protection and Privacy Regulations, 2021, r.30** addresses demonstration to PDPO of adequacy or consent, and says onward processing/transfer to a third country requires express consent; identify all subprocessors, including support, model inference, error logging and disaster recovery. Do not assume selecting Germany automatically satisfies these obligations.
3. **Regulation 15** and published PDPO guidance require registration of relevant data collectors, processors and controllers unless a valid exemption applies. Ask counsel to verify latest registration and reporting obligations for AMAALPROP as operator and customer landlords as controllers.
4. **Regulation 12** requires a data protection impact assessment for processing that poses a high risk to rights/freedoms. Because the product handles IDs, contact details, property tenancy, financial evidence, tenant profiling and optionally AI, conduct and document a DPIA before real production data.
5. **Regulation 33** describes breach notification **immediately** after the breach; do not substitute a generic "72-hour" timeline. Maintain an immediate escalation path with counsel/DPO and a regulator notification template.
6. **Regulation 29** addresses correction/deletion requests and written decisions within seven days of receipt. Define ownership and complaint-handling procedures.
7. Published PDPO registration guidance describes one-year registration validity, renewal in the prior three months and annual compliance reporting. The 2026 PDPO Knowledge Center advertises a **23 November 2026** annual compliance report deadline; determine applicability with counsel.

### Primary sources checked

- Uganda Data Protection and Privacy Act 2019: https://ulii.org/en/akn/ug/act/2019/9/eng%402023-12-31
- 2021 Regulations: https://pdpo.go.ug/media/2022/03/Data_Protection_and_Privacy_Regulations-2021.pdf
- PDPO registration guidance: https://pdpo.go.ug/media/2022/01/20102021105143-Registration_Classification_and_Guidance_Notes.pdf
- PDPO 2026 Knowledge Center: https://pdpo.go.ug/knowledge-center
- Render regions/private networking: https://render.com/docs/regions and https://render.com/docs/private-network
- Vercel compute regions: https://vercel.com/docs/functions/configuring-functions/region
- Cloudflare R2 jurisdiction: https://developers.cloudflare.com/r2/reference/data-location/

## Decision on legal roles and data flows

**Recommended contractual model** (requires legal approval):
- Each property organisation is the **controller** of its tenants'/staff's property-management records for its business purposes; AMAALPROP is a **processor** for those workflows, following documented instructions and contractual controls.
- AMAALPROP is also a **controller** for its own SaaS registration, authentication/security logs, billing of its customers and product support purposes. Record these distinct purposes in privacy notices and data flow maps.
- NestJS/Rust, Vercel, Render, Neon, R2, Auth0, email, SMS, support, analytics and later AI are separately mapped as internal services or subprocessors with lawful roles. No customer document data sent to AI by default.

## Production data release gate — evidence required, not optional

- [ ] Responsible Ugandan counsel/DPO confirms operator role, controller/processor allocation, notices, lawful grounds, registration and ongoing reporting duties; provide registration certificates/filing evidence as applicable.
- [ ] Cross-border transfer assessment documents actual countries for processing/storage/backups/logging/support, legal basis/consent or adequacy evidence, r.30 onward-transfer restrictions and PDPO position if required. If this cannot be supported, **choose a compliant alternative hosting geography/provider** before processing real data; do not bypass gate with a checkbox.
- [ ] Complete DPIA, data-flow diagram, special-category screening, threat model and explicit decisions for IDs, bank data, inspections and AI.
- [ ] Signed, reviewed vendor DPA/subprocessor terms and cross-border transfer terms for **each** relevant provider; obtain subprocessor lists and security statements.
- [ ] Purpose-based privacy notices, consent records where relied upon, access/correction/deletion/export workflow, objections and complaints channels.
- [ ] Confirm retention schedule with legal/accounting review; restrict legal holds, evidence preservation and immutable financial posting appropriately.
- [ ] Confirm actual regions and configuration for Vercel Functions, Render services, Neon database and backup, R2 `eu` jurisdiction, identity provider, email, logs, monitoring, AI and support access.
- [ ] MFA, least-privilege IAM, credential rotation, RLS negative tests, tenant-safe caches/logs, file scanning and WAF configured and tested.
- [ ] Database PITR + offsite restore and R2 recovery exercised using non-production or safely anonymised data; backup encryption keys and access policy reviewed.
- [ ] Breach runbook and PDPO Form 7 escalation templates, incident owner, 24/7 escalation contact, tabletop test, evidence preservation and customer notification process.
- [ ] Recorded sign-off by product owner, DPO/legal and engineering lead. **No production launch until every applicable check passes.**

## Retention and security defaults — operational **proposals**, not statements of legal minimum

| Class | Default for preproduction configuration | Final authority |
|---|---|---|
| Financial ledger, receipts, reconciliation and transaction documents | 7 years after financial year/record close (provisional) | Uganda tax/accounting/legal review; do not erase posted journals |
| Lease documents and contractual notices | 7 years after lease end (provisional) | Counsel/lease retention rules |
| Identity evidence | Minimise; retain verification result and masked identifiers; raw copies default 90 days after verification unless necessary | DPO purpose/retention approval |
| Inspection photos/clearance files | 3 years after case closure (provisional) | Lease, dispute and litigation-hold requirements |
| Operational audit | 2 years accessible + policy-based archive (provisional) | Security/legal review |
| Redacted application logs | 30 days | Incident/monitoring requirements |
| Backup restore windows | Target 30 days with separate tested restore copies | RTO/RPO and provider contract |
| Unused invitations and one-time tokens | 72-hour invitation TTL; tokens deleted/revoked after use/expiry | Authentication product policy |
| AI request/input retention | Disabled until explicit privacy review; prefer zero-retention provider configurations | DPIA + vendor DPA |

**Retention implementation:** `retention_policies`, `record_retention_assignments`, `legal_holds`, `data_subject_requests`, `erasure_jobs`, `breach_incidents`, `processor_register`, `consent_records` and `data_processing_purposes`. All deletion is idempotent, scope-checked and auditable. Financial records subject to legal retention are restricted/de-identified where allowed rather than silently erased; backups age out under a verified lifecycle.

## Recovery and production-service targets (initial SLO policy)

- Production DB availability follows purchased vendor SLA; AMAALPROP **internal** initial recovery targets: **RPO <= 1 hour, RTO <= 8 hours**, **subject to successful restore tests and product-owner acceptance**. Do not advertise these as achieved until proven.
- Health endpoints `/health/live`, `/health/ready`; retry/timeouts/circuit breakers for Nest -> Rust and external providers.
- A financial posting succeeds only if its Rust transaction succeeds. Pending mail/SMS/AI failures cannot roll it back or replay the posting. Worker retries deduplicate.
- Staging always contains synthetic/anonymised data; production audit and data export access is logged and restricted.

## Current connector readiness (read-only checks on 13 Nov 2026)

- **GitHub:** authenticated profile works; GitHub App installation listing returned none. Repository-specific write access **not demonstrated**; requires installation/grant after repo creation.
- **Vercel:** teams/projects readable; do not assume AMAALPROP deployment access until new project permission check.
- **Render:** workspaces/services readable; use a new AMAALPROP environment, not existing unrelated services.
- **Neon:** organisations/projects readable; establish new AMAALPROP project/branch and database role isolation.
- **Cloudflare:** identity, zones and R2 bucket listing readable; three R2 buckets were found, **not validated as AMAALPROP EU-jurisdiction buckets**. Create a new purpose-specific EU bucket after authorisation.
- **Resend:** transactional email connector lists one verified sender domain with EU region, but it is not automatically an AMAALPROP-approved sender/brand; verify domain ownership, sender addresses, permissions and legal data processing.
- **Auth0, SMS, monitoring and model provider:** not connected or verified for this product. Select/vendor-onboard by phase before production use.

**Do not create, deploy or modify any provider resource as part of this document review.**
