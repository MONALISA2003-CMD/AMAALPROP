# AMAALPROP — Phase 0 evidence-based status

**Status:** PARTIAL — local scaffold present; remote integration and release gates **NOT** complete.
**Checked:** 13 November 2026. Only AMAALPROP resource names were considered.

## Existing code in uploaded Phase 0 snapshot

- Next.js web placeholder, NestJS public gateway, Rust/Axum core and shared Rust crate,
  Rust worker idle process, Docker/Compose definitions, CI workflow, synthetic-only guards.
- Signed gateway-to-core synthetic probe with issuer/audience/time/route checks.
- Uploaded snapshot reports previously passing Node/Rust builds and boundary tests, but those
  reports do **not** establish live Render deployment or repeatable CI success for this revision.

## Corrections in this repaired snapshot

- Restored full original v1 root docs (rather than overwriting existing GitHub content with
  131-byte redirects), removed the duplicate backup subtree.
- Removed persistent Phase 0 SQL synthetic migration/fixture. Local test is transaction-scoped,
  rolls back its role, schema and test rows and rejects non-local PostgreSQL URLs.
- Added checked provisional OpenAPI and repo doctor; cleaned up Phase 0 instructions.
- Preserved synthetic-only service boundaries; Vercel postponed, no real customer data.
- Added provider wiring checklist; Render configuration is **proposed**, not applied.
- Adjusted Phase 0 exit gate to distinguish local tests from remote deployment.

## Read-only provider verification

| Check | Evidence | Result |
|---|---|---|
| GitHub | `MONALISA2003-CMD/AMAALPROP` exists, main contains 6 documentation files | EXISTS; this scaffold is not on main |
| Render | One accessible workspace; listing its services contained no AMAALPROP named services | **NOT LOCATED**; user says they exist, workspace mapping needs confirmation |
| Neon | project `amaalprop-v2-staging` (`royal-flower-91615135`) | EXISTS |
| Neon branches | `staging` default; `development` additional | EXISTS |
| Neon schema | staging: no tables, only `amaalprop_migrator` role; development: `synthetic.organisation_probe`, `amaalprop_runtime` and `amaalprop_migrator` roles | VERIFIED; no change made |
| Vercel | no AMAALPROP project/repo association identified | NOT CONNECTED/DEFERRED |
| R2/identity/email | no AMAALPROP-specific binding verified | DEFERRED; don't reuse unrelated resources |

## P0 exit status

| Gate | Status |
|---|---|
| V2 architecture/repository/dependency plan | READY IN FILES |
| Web/gateway/core/worker code scaffold | PRESENT; requires clean CI rebuild |
| Local signed gateway->core boundary tests | Source tests present; must rerun after publish |
| Disposable, fail-closed RLS harness | PRESENT; local PostgreSQL execution pending |
| API OpenAPI provisional contract/drift test | PRESENT |
| GitHub PR, review, branch rules and CI green | **NOT COMPLETE** |
| Known AMAALPROP Render service IDs and private link | **BLOCKED: service/workspace not found** |
| Render deploy and remote signed internal smoke | **NOT COMPLETE** |
| Neon runtime role and DB wiring | **NOT COMPLETE** (deliberately no migration into staging) |
| Vercel connection | DEFERRED; not a Phase 0 blocker for backend-only staging |
| Production customer data clearance | NOT ALLOWED; separate P9 gate |

**Never mark P0 complete just because the configuration exists.**
