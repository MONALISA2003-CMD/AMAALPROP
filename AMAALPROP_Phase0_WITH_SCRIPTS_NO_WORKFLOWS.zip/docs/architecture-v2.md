# AMAALPROP — Architecture v2: Rust + NestJS

**Decision date:** 13 November 2026  
**Status:** Implementation architecture baseline; no customer-data deployment approved  
**Supersedes:** Technology and deployment decisions in `architecture.md` v1, `tech-stack (1).md` v1 and `repo-structure.md` v1 where they disagree.  
**Source product rules preserved:** AMAALPROP PRD v1 and ERD v1, except explicit refinements recorded in the v2 decision log.

## ADR-001 — Use both Rust and NestJS, but only one authoritative business backend

**Decision: ACCEPT FOR IMPLEMENTATION DESIGN.** Use the two languages for different layers, not two competing copies of the business application.

| Runtime | Deploy | Owns | Must never do |
|---|---|---|---|
| Next.js/TypeScript web | Vercel | Responsive landlord/staff app, tenant portal, OIDC browser login/session, server-side BFF calls, UI validation | Connect to PostgreSQL; issue ledger postings; trust UI permissions |
| **NestJS/TypeScript API gateway** | Render public web service | `/api/v1` REST interface, request schemas, authentication/JWT validation, rate limiting, request tracing, OpenAPI, API aggregation, pagination/representation, signed internal delegation | Directly query/write PostgreSQL; own tenant, lease, payments or ledger state; decide financial transitions |
| **Rust/Axum core** | Render **private service** | The **one authoritative modular monolith**: identity mapping and membership, organisations, role/scope decisions, property, tenant, lease, approvals, billing, payments, ledger, maintenance, clearance, documents, outbox and audit | Trust organisation IDs or authorization decisions solely because NestJS supplied them; expose a public financial API |
| Rust background worker | Render background worker | Reuses Rust core domain crates and repositories; reliable outbox, recurring invoices, notifications, reminders, reconciliation processing | Duplicate command effects on retry; bypass RLS/context |
| Python/FastAPI AI (later) | Render private service | Optional document extraction, RAG, read-only analytics and human-reviewed suggestions | Autonomously approve, verify funds, refund, alter leases or post journals |
| Neon PostgreSQL | EU-Central Frankfurt **candidate** | Relational system of record, SQL migrations, RLS, constraints and transactions | Allow public browser direct access; use an elevated runtime DB role |
| Cloudflare R2 EU-jurisdiction **new buckets** | Cloudflare | Private documents/evidence/backups (subject to policy) | Issue public permanent URLs to personal files |
| Cloudflare edge | Cloudflare | DNS, DDoS/WAF, TLS, selected rate limits; no private-content caching | Substitute for app authentication, database RLS or regional processing guarantees |

**Why this is still a modular monolith:** Rust modules own every domain mutation and are built/deployed as one core executable plus a worker using the same crates. NestJS is an API experience/transport layer, **not** a second autonomous property-management service. Distinct runtimes do add deployment complexity; this is a conscious tradeoff for using both languages.

```mermaid
flowchart LR
 Browser[Browser] --> CF[Cloudflare edge]
 CF --> WEB[Next.js on Vercel]
 WEB -->|server-to-server access token| G[NestJS public API on Render]
 G -->|private network + signed delegation| R[Rust private core on Render]
 R --> DB[(Neon PostgreSQL)]
 R --> OBJ[(Private EU R2)]
 W[Rust background worker] --> DB
 W --> OBJ
 R -. optional internal auth .-> AI[Python AI private service]
```

## ADR-002 — Trust boundaries and authentication flow

1. Use **one managed OIDC identity tenant (Auth0 selected as implementation default)**, with Authorization Code + PKCE. Do not create a separate Auth0 tenant per landlord organisation. Secrets are server-only. *Vendor account and contract are not yet connected/verified.*
2. Next.js owns an encrypted, Secure, HttpOnly, SameSite=Lax browser session; authenticated browser operations use same-origin Next route handlers, not directly stored bearer tokens or long-lived `localStorage` secrets. Enforce CSRF on state-changing browser-originated requests, and `Cache-Control: private, no-store` on private data.
3. Next server forwards a short-lived, audience-scoped IdP access token to NestJS. NestJS validates issuer, audience, signature, expiry, not-before, allowed algorithm and keys via JWKS; rejects malformed and unsigned tokens. NestJS does **not** infer organisation access from the token's email.
4. NestJS calls Rust over Render private network, using a signed short-lived internal assertion bound to the validated IdP subject, request/correlation ID, actor/client type and audience; rotate service keys. Rust validates the assertion and maps `issuer + subject` to `external_identities` and `user_accounts`.
5. **For every protected transaction Rust resolves active membership, permissions, asset scope and workflow conditions from its own database.** Missing/revoked access fails closed. It derives `organisation_id` internally, opens a DB transaction and applies `SET LOCAL app.organisation_id` (and actor context), using a restricted runtime DB role with RLS. Pooled connections must not leak context.
6. Public `/api/v1` lives on NestJS. Internal Rust APIs use `/internal/v1` and service-to-service authentication; never expose an internal Rust service publicly. Scheduled jobs use service identity + explicit trusted organisation context revalidated against the target record.
7. Passwords/recovery/MFA are managed through the IdP. Require MFA for owner, finance, approver, and admin roles; use step-up authentication for refunds, owner transfers and privileged role grants. Rust owns *authorisation*, not password storage.

## ADR-003 — API and ownership contracts

- NestJS exposes only versioned REST endpoints and generates a versioned, checked-in OpenAPI schema (`contracts/public-api/openapi.yaml`). The web client is generated from it; contract tests compare NestJS and Rust internal DTOs. No unversioned hand-written API duplication.
- NestJS is allowed read aggregation, transformation and safe stateless validation; no domain-side transaction orchestration spanning separate Rust calls for financial writes. Use one Rust **command endpoint** for an atomic workflow (e.g. `POST /payments/submissions/{id}/verify`).
- All business write requests require an idempotency key or server-generated deterministic command ID. Forward caller and trace context to Rust, with a known timeout and no unsafe automatic retries of non-idempotent calls.
- Rust domain modules expose explicit ports; persistence adapters cannot write another module's tables without invoking its service. Rust owns outbox and audit writes in the business transaction.
- Error codes are stable and do not reveal cross-tenant resource existence. Treat forbidden cross-tenant IDs as 404 where appropriate; internal logs preserve a security-event classification.
- Future mobile uses the same NestJS `/api/v1`; mobile OAuth uses PKCE and secure OS token storage, but is out of the initial release.

## ADR-004 — One source of truth for data, finance and RLS

- **Database:** PostgreSQL in Neon, SQLx-managed migration sequence under `database/migrations`. NestJS does **not** use Prisma/TypeORM against production tenant data.
- **Money:** `NUMERIC(20,4)` exact decimals in DB and `rust_decimal` in Rust; enforce ISO currency precision (UGX zero fractional minor units) and explicit rounding at edges. Launch configuration is UGX-only per Ugandan organisation; foreign currency transactions are not enabled until a later accounting policy release.
- **Accounting:** accrual posting for issued invoices, verified collections, expenses and refundable deposits; optional cash-basis **reports** are derived, not a second ledger. Original posted journals remain unchanged even when reversed; separate reversing journals and links.
- **Transactions:** accounting posting, payment state transition, receipt creation, allocations, audit and outbox events take place atomically when part of the same command. Unique source keys and locks prevent duplicates.
- **RLS:** `organisation_id` on all tenant-owned high-risk tables, composite same-org foreign keys, restrictive `USING`/`WITH CHECK` policies and no production database owner credentials in runtime. Special non-tenant global account tables use tightly restricted access via audited Rust identity services.
- **Scope assignments:** use typed scope links or equivalent composite FK-backed validation; reject unverified polymorphic `scope_type + scope_id` relations.

## ADR-005 — Async, storage and observability

- Rust outbox and worker on Render initially; ordered work where needed by aggregate key; at-least-once delivery with dedupe and dead-letter review. No mandatory Kafka/Redis/microservice broker.
- File uploads use an upload-intent record, content scan, checksum, classification, lifecycle state and private S3-compatible object storage. Only Rust authorises signed URLs; client never chooses arbitrary object keys. Tenant files are separately authorised at tenant-party/lease scope.
- Structured logs, request IDs, error reporting, deployment metrics and security events across Next/Nest/Rust/worker; redact names, IDs, tokens, bank information and document contents from telemetry.
- CI: TypeScript lint/typecheck/tests, Rust fmt/clippy/tests, SQL migration/RLS tests, OpenAPI compatibility, Playwright E2E, secret scanning, SCA and container scanning. Migrations deploy separately before incompatible code; staging restores are mandatory.

## ADR-006 — Hosting region and customer-data gate

**Topology choice:** Vercel web, Render Frankfurt public NestJS + private Rust core + worker, Neon Frankfurt (`aws-eu-central-1` where available) and **new EU-jurisdiction R2 buckets**. Place Vercel compute in `fra1` if server-side compute is needed; confirm failover/edge/logging jurisdiction policies. Cloudflare DNS/WAF at the edge with private API responses non-cacheable.

**This is a technical topology choice, not authorisation to process Ugandan customer data overseas.** Only synthetic/non-identifiable test data is permitted before the cross-border privacy assessment and required legal approvals. See `hosting-data-protection-v2.md` for the release-blocking checklist. Existing projects/buckets shown in connected accounts belong to other work unless explicitly assigned; do not repurpose them by assumption.

## Accepted omissions and later work

- Python AI service is optional Phase 8; no AI decision-making over finance, approvals or lease termination.
- No direct bank/mobile-money connection for landlord collections in MVP. The platform accepts evidence of external payments and requires independent human verification.
- No live cash collection in MVP, no fractional property ownership, no marketplace, no C++ component.
- No mobile app until the web product and API have been validated.

## Required test scenarios before shipping

- Cross-org/tenant read, write, file, export and worker access forbidden, including after transfer/revocation.
- Next -> Nest -> Rust permission checks cannot be bypassed by forged org IDs, internal headers, service assertions or stale tokens.
- Invoice scheduler/job retries produce one invoice per schedule cycle.
- Posting, allocations, refunds, reversals and close-period operations are atomic, balanced and protected against concurrency.
- Tenant co-occupancy and multi-unit leases respect configured capacity; portal co-tenants cannot read one another's private identity or payment evidence.
- Legal/privacy launch gate and restore drill both pass with documented evidence.

## Decision log and source provenance

- **From PRD/ERD v1:** global login uniqueness, one-organisation membership, one designated owner, tenant/employee profile separation, scoped roles, external payment verification, double-entry ledger, deposit liability and clearance order.
- **From stack v1:** Next.js, Rust/Axum/SQLx, PostgreSQL/Neon, Render, Vercel, GitHub, Cloudflare, Python AI later.
- **New engineering decisions in v2:** NestJS gateway-only responsibility, Auth0 default IdP, Next-owned browser session, strict one-org rule extended to all portal logins, UGX-only accrual launch, new EU-jurisdiction storage, no launch cash collection, and concrete lifecycle/release controls. These are **proposals resolved here for implementation planning**, not statements that the product owner previously approved them.
