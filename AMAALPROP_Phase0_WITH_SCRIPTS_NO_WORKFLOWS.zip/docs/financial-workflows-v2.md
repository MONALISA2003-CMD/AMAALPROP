# AMAALPROP — Financial Posting and Workflow Rules v2

**Status:** Engineering specification for initial Uganda/UGX release; tax rates, legal retention, and refund/deposit legal grounds require professional approval before real production use.  
**PRD concepts preserved:** external landlord payment instructions, tenant submissions, authorised independent verification, double-entry accounting, deposit liabilities, approvals and audited clearance.

## 1. Policy defaults selected for build

| Policy | Engineering decision |
|---|---|
| Accounting basis | **Accrual** as the canonical ledger. Cash-basis management reports are optional derived views; never a separate posting ledger. |
| Currency | **UGX-only transactions** at initial Uganda launch; `NUMERIC(20,4)` storage with 0 fractional UGX units and exact decimal calculations. Foreign-currency UI, conversion postings and FX gains/losses disabled until separately approved. |
| Tax | Tax codes and effective-date mappings required; no hidden default tax rate. Where legally relevant but unconfigured, invoice issue is **blocked**. Country accountant signs off tax and withholding configuration. |
| Landlord payment collection | External bank/mobile-money instructions, **manual evidence-backed staff verification**. No API-required bank connection. |
| Cash | No on-site cash collection/issuance in first release (planned adapter but disabled). |
| Deposit | Fully separate liability, not rent income. Deposit refunds/deductions require settlement evidence and approval. |
| Overpayment | Unapplied tenant receipts remain a liability until valid allocation, refund or deposit transfer. |
| Liability among co-tenants | Explicit `lease_liability_shares` per charge/lease participant. No assumption of joint and several liability; contract-specific legal terms require reviewed configuration. A shared invoice needs explicit liable party/share allocation. |
| Approvals | Maker/checker on payment exceptions, refunds, financial adjustments, supplier disbursements and deposit deductions; owner/finance MFA and step-up as needed. |
| Financial period | Monthly periods, explicit closing controls. Exceptionally reopen only through independently approved, audited command. |

## 2. Posting matrix (examples, not tax/legal advice)

| Event/authorised command | Debit | Credit | Commit conditions |
|---|---|---|---|
| Issue posted rent invoice | Tenant accounts receivable | Rental income (+ tax liability if configured) | Approved active lease/schedule, correct due dates, tax mapping, open period; invoice and journal in one transaction |
| Verify external rent-related payment | Bank/mobile-money clearing/control account | **Unapplied tenant receipts liability** | Independent proof of receipt, verifier role and scope, source reference dedupe; create payment, journal and receipt atomically |
| Allocate verified receipt to invoice | Unapplied tenant receipts liability | Tenant accounts receivable | Same party/currency/org, outstanding invoice, available unallocated credit, transaction lock |
| Receive refundable deposit | Bank | Refundable tenant deposit liability | Confirmed funds; if processed via generic receipt, transfer *unapplied* to deposit liability instead of double debiting bank |
| Transfer verified unapplied receipt to deposit | Unapplied tenant receipts liability | Refundable tenant deposit liability | Same org/currency/party and approved deposit rule |
| Post supplier bill | Maintenance/operating expense or asset | Accounts payable | Supplier, approved evidence, expense account/tax reviewed, open period |
| Pay supplier bill | Accounts payable | Bank | Independent payout confirmation, authorised payment, reconciliation reference |
| Issue approved rent credit note | Rental income adjustment / tax reversal | Tenant accounts receivable | Credit note linked to invoice line, approved reason, amount cannot exceed eligible amount |
| Refund unapplied tenant credit | Unapplied tenant receipts liability | Bank | Approved refund **and** actual payout confirmation; cannot exceed free liability |
| Refund deposit | Refundable tenant deposit liability | Bank | Final approved settlement, confirmed payout, no unresolved contested deduction |
| Apply deposit to approved arrears | Refundable tenant deposit liability | Tenant accounts receivable | Lawful contractual basis, charge/settlement evidence, independent approval, exact outstanding invoice |
| Apply deposit to approved damage charge | Refundable tenant deposit liability | Tenant accounts receivable | Separate lawful damage invoice/charge and approved settlement; no direct magic transfer to income |
| Reverse erroneous original | Reverse the original posted journal with new posted journal | N/A | Approved reason, period policy and `journal_reversal_links`; never edit/delete original |

**Bank posting choice:** If a verified provider statement indicates actual cleared bank funds, debit the bank GL account. If only payment-channel clearing evidence is available, use a configured mobile-money clearing account and reconcile it to the destination bank later; **do not claim bank-cleared funds from a screenshot**.

## 3. Detailed payment lifecycle

`submitted -> under_review -> verified | rejected | duplicate | disputed | cancelled`.

- Submitter supplies transaction ref, amount, date, channel, instruction used and optional private proof. Submission alone has **no payment, journal, allocation, receipt or financial-health clearance**.
- Reviewer sees the bank/mobile-money transaction evidence (imported statement row or independently observed provider confirmation). Store `payment_verification_evidence` with source/hash, channel, actual amount/date, reviewer and notes. A screenshot or matching reference alone is insufficient. If an externally observed payment cannot be independently substantiated, keep `under_review/disputed`, not verified.
- Rust verification command locks the submission + candidate bank evidence and performs idempotency check. Enforces verifier != original staff entry actor, `payment.verify` permission, org/scope and evidence uniqueness.
- In **one database transaction**, create confirmed `payments`, post balanced journal, `unapplied_receipt_movements`, number/issue `receipts`, mark submission verified, create append-only event/audit/outbox. Failure rolls the entire command back.
- Allocation is separate or part of a single verified-command subtransaction. It locks invoice and unapplied credit, posts balanced transfer from liability to AR, and derives invoice status. Multiple partial allocations supported; no allocation beyond free credit or invoice balance.
- Reversal/refund does not delete old receipt: generate reversal journal/linked follow-up document and adjusted tenant statement. If funds are returned by provider (reversed/chargeback), follow distinct evidence-backed reversal command with debt reinstatement as needed.

## 4. Idempotent recurring invoice lifecycle

`draft schedule -> approved/active -> suspended/ended` with a versioned charge policy; each run creates `(organisation_id,schedule_id,cycle_key,policy_version)` once. Advance/arrears logic, month end, leap years, prorations and selected Africa/Kampala business date are deterministic. The invoice issue command posts AR/revenue in the same transaction with immutable invoice line snapshot and outbox event. A repeated job, API request or worker crash produces the same source result, not a second invoice.

Invoices cannot be mutated after issue; issue `credit_notes`, properly approved invoice adjustments or later re-billing. Status `paid`, `part_paid`, `overdue` is computed from posted receivables/credits, amounts and due-date policy version; don't store independent editable balances.

## 5. Expenses and supplier bills

`draft -> submitted -> approved | rejected -> posted_payable -> payment_authorised -> paid/part_paid -> reconciled`.

- Suppliers and vendor bills have their own master and double-entry payable model, rather than free-text supplier names inside expense records.
- Requester and approver distinct where expense policy requires; sensitive beneficiary changes require step-up verification.
- Bill approval does not imply cash disbursement. Posted bill credits AP; confirmed payment clears AP against bank; reconciliation matches distinct bank statement line. Preserve partial supplier payments and withholding/tax mappings where approved.

## 6. Refunds, deposit deductions and disputes

`draft -> submitted -> approved/rejected -> processing -> paid/failed/cancelled`. No refund journal at `approved` or `processing`; only on confirmed disbursement. Bank destination changes after approval require resubmission. All payout confirmations and unique bank references are recorded.

Deposit settlement has immutable draft versions and line-item evidence: original balance, unpaid approved rent/utility charges, damage evidence, disputable items, approved deductions, refundable residual, payer destination, requested/approved/paid status. Disputed deduction is not silently treated as accepted; block that line pending documented lawful resolution, while preserving lawful lease exit/notice independent of money dispute.

## 7. Clearance and approval state machines

### General approval engine

`draft -> submitted -> step_in_review -> approved | rejected | returned | withdrawn | expired`. The request stores **the exact approval policy version**, source record version and monetary amount snapshot; a materially changed source invalidates approval. Decisions are append-only. Delegate authority must be explicitly granted, time-bound, scoped and no greater than original authority. No self-approval of refunds or financial adjustment.

### Move-out clearance

1. Tenant submits notice (`move_out_requests`) and creates `clearance_cases`, potentially multiple `clearance_case_units` for one lease.
2. Caretaker assigned only to relevant property submits inspection with immutable template version and private evidence.
3. Property manager (different actor) verifies each inspection, may return for corrections.
4. Finance computes `deposit_settlements` against **posted** AR/unapplied receipts/deposit liabilities, not editable balances; dispute handling explicit.
5. Landlord or documented delegate gives final clearance approval after physical/finance prerequisites. Actor is independent as policy requires.
6. Key handover and unit occupancy closure recorded per unit. `lease_terminated/expired` **legal/contractual state** is not simply the physical or financial status and must be set by authorised lease process per effective contractual date.
7. Final case closure does not erase accounts, inspection reports, rights or unresolved claims.

## 8. SQL and application invariants

- `UQ(org,source_module,source_record_id,posting_action,source_version)` for journals; unique receipt per confirmed payment, unique statement import line fingerprint and refund disbursement source. Idempotency keys compare request body hash to reject key reuse with different payload.
- Post journal only through transaction-bound posting service; at least 2 lines, each line one nonzero debit/credit, accounts in same org, active account and open period, total debit=credit in base currency and transaction currency as configured. Use DB immutable-entry/line guards and checks; no update/delete of posted artifacts.
- Reversal must be a new journal (equal/opposite), linked to original; enforce only one active full reversal per original action unless adjustment policy explicitly handles partial corrective entries.
- Financial balance/statement derives from posted journals and allocation events; snapshots are discardable/rebuildable caches with version and reconciliation checks.
- A background notification failure never duplicates accounting. A failed bank-import operation does not create unverified payments.
- All posting, bank matching, approval and owner/tenant scope checks are independently tested under concurrency and RLS runtime roles.

## 9. Day-one finance test ledger (must all pass)

1. Create UGX 1,000,000 monthly rent invoice: AR +1,000,000 and income +1,000,000; no fractional UGX.
2. Tenant submits claimed 1,000,000: no ledger impact, no receipt.
3. Staff finds only 800,000 cleared against a claimed 1,000,000: move submission to `disputed` and request correction; **do not silently verify 800,000 as though the original claim matched**. After an authorised corrected submission is confirmed for 800,000, post Bank +800,000 and Unapplied liability +800,000 and issue receipt for 800,000.
4. Allocate the independently confirmed 800,000 to invoice: Unapplied liability -800,000, AR -800,000; invoice outstanding =200,000; status computed, not manually changed.
5. Retry verification 20 times in parallel: one payment, receipt, journal, source posting and audit command result.
6. Receive 500,000 refundable deposit: bank +500,000 and liability +500,000, not income.
7. Issue approved 50,000 rent credit note: reduce AR and correctly reverse income/tax mapping; outstanding now 150,000 in example.
8. Attempt unauthorised 300,000 refund on zero unapplied credit: rejected; no journal. Test that original 1,000,000 claim remains documented as disputed/corrected, not silently overwritten.
9. Create supplier bill for 200,000 and pay 100,000 only after approval/confirmation: payable outstanding 100,000.
10. Simulate reversal, retry, closed period and two-organisation cross-scope attack: immutable original journal, balanced reversal in valid open period, and no cross-org effects.

## 10. External approvals still required before live finance

- Uganda-qualified accounting review: chart of accounts, rental revenue recognition, tax code/withholding, deposit settlement treatment, statutory reports and reporting basis.
- Product owner: policy thresholds and whether a second organisation representative/platform officer can approve for one-person landlords. **Default is fail-closed where separation cannot be met.**
- Uganda legal review: lease termination/legal notice, deposit deductions, tenant consent/notice, financial retention and payment dispute handling.
- Provider/technical: independent bank/mobile-money verification evidence protocol and secure storage/recording, access to live provider statements, reconciliation and notification operations.
