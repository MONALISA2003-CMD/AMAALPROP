# AMAALPROP — Identity, Membership and Authorisation Contract v2

**Status:** Implementation-ready design decision (policy sign-off recommended). **Supersedes** ambiguous membership wording in the PRD v1, ERD v1 and architecture v1.

## Locked business interpretation

1. One *global* login identity per canonical, verified email in AMAALPROP (`UNIQUE(user_accounts.normalised_email)`). Public organisation/property contact emails are **not** login identities.
2. One account may be associated with **at most one property organisation at a time** in any active/reserved membership state. This includes **owners, staff, contractors, auditors, tenants, and occupants with portal access**. A non-login tenant profile in another organisation is permitted, but it does not grant access. A person seeking login to two organisations must use two different email identities; the UI explains this restriction.
3. A user may have *multiple capacities inside the same organisation*, e.g. employee and tenant. **Never make a single `membership_type` enum the exclusive representation of capacity.** Use membership + `membership_capabilities` + organisation-scoped `roles` and `tenant_portal_grants`.
4. `user_accounts`, `external_identities`, `organisation_memberships`, `tenant_parties`, `tenant_persons`, `occupants`, `lease_participants`, `employee_profiles` and `tenant_portal_grants` remain different records. A login is not a lease participant or legal owner.
5. There is exactly **one current designated owner membership per active organisation**. Pending registration has a reserved owner; owner change uses a controlled two-person transfer, preserves old appointments and never rewrites audits.
6. Hierarchical supervisor relationships do not imply access. Every action independently checks active membership, permission code, applicable scope, workflow state and, when required, separate approval authority.

## Canonical identity and email handling

- Use an Auth0-managed OIDC identity subject with a stable `(provider_issuer, provider_subject)` unique index. Handle email update by a separate confirmed app-side flow.
- Canonicalise email: trim surrounding whitespace, Unicode NFC, case-fold consistently per platform policy, canonicalise IDN domain to ASCII, then enforce uniqueness within a DB transaction. **Do not** strip dots or `+tag` segments because their semantics differ by provider. Retain original display value for notifications. Confirm verified email before activation.
- Email may identify a pending invitation, but never entitles access based solely on matching text. Invitation tokens: random 256-bit or stronger, hash at rest, expire in 72 hours by default, single use, rate-limited. Never expose whether another email belongs to another organisation in public responses.
- Account status: `pending_email_verification -> pending_approval -> active -> suspended -> disabled` with explicit restoration, revoke-session events and security logging. Sessions for deactivated/suspended accounts must fail membership lookups immediately even if an IdP token remains valid.
- A pending invitation reserves the canonical email/target organisation for the invitation window. Expired invitations release reservations. Only confirmed, applicable invitations can create the member record.
- A tenant person/profile can exist without an email, and the same tenant party may have multiple related natural persons. Company tenant representative grants have a separate limited-capacity designation.

## Database model and constraints

| Table | Key fields and constraints |
|---|---|
| `user_accounts` | `id PK`, `normalised_email CITEXT/unique text UQ`, `email_verified_at`, `status`, `created_at`; no organisation ID; optional display email |
| `external_identities` | `id`, `user_account_id FK`, `issuer`, `subject`, `last_verified_at`, `UQ(issuer,subject)` |
| `property_organisations` | `id`, `status`, `owner_membership_id` nullable during onboarding, unique/validated in active state, base currency/time zone |
| `organisation_memberships` | `id`, `organisation_id`, `user_account_id`, `status`, effective dates, revocation audit; multiple *historical* memberships allowed over time |
| `membership_capabilities` | `organisation_id`, `membership_id`, `capability` (`owner`,`employee`,`tenant`,`contractor`,`auditor`,`occupant`), `valid_from`, `valid_until` |
| `employee_profiles` | `organisation_id`, `membership_id`, human HR/contact fields only; no credentials; `UQ(organisation_id,membership_id)` |
| `tenant_portal_grants` | `organisation_id`, `membership_id`, `tenant_person_id` and/or `party_id`, grant scope, approved-by, accepted-at, status, revocation-at |
| `organisation_owner_appointments` | `organisation_id`, `membership_id`, `appointed_at`, `ended_at`, transfer request/approval IDs; `UQ(organisation_id) WHERE ended_at IS NULL` |
| `identity_invitations` | hashed token, canonical email, org, invite type, expiry, issuer, proposed grants, status, `accepted_at` and approved-by |
| `identity_email_change_requests` | old/new canonical email, verification challenge hash, TTL, state, audit actor; resolve collisions transactionally and reconcile IdP |
| `organisation_transfer_requests` | old/new org, membership, start/end dates, approvals and evidence, status; never mutate historical membership organisation IDs |
| `role_permissions`, `user_role_assignments` | standard role -> stable permission relationship and actor/time-bound assignment |
| `scope_assignments` | org/member plus typed FK scope owner and effective dates; if polymorphic ID retained, validate in trigger and service and test cross-org rejection |
| `approval_delegations` | org, delegator, delegate, scope, permission, amount bound, effective interval, revoked-at; never widen original authority |
| `security_events` | global restricted account security audit, actor, reason, action, timestamp, network metadata redacted |

**Partial unique index** on memberships: one live/reserved organisation association per account (`status IN ('invited','pending_approval','active','suspended')`), with transition logic that revokes old membership before activating a new one; optionally lock the account row to serialise racey invitations. `UQ(organisation_id,user_account_id)` applies to current versioned identity; history is stored in `membership_events` or historical membership versions, not duplicate live rows.

**Owner constraint:** one active owner appointment by partial unique index; organisation becomes `active` only if referenced owner membership is active, has `owner` capability, and belongs to that organisation. Enforce using a deferred trigger/transaction. Owner membership cannot be revoked until a successor is approved and activated atomically.

**Composite integrity:** every scoped FK is `(organisation_id, referenced_id)` where possible. All role grants, approvals, portal grants, scope assignments, lease/tenant joins and file associations enforce identical organisation ownership.

## State machines, operational behaviour

### Organisation registration
`draft -> pending_email_verification -> pending_review -> active | rejected`; `active -> suspended -> active | closed`. The single founding owner is reserved during onboarding; no real tenant data or live finance before organisation verification and platform privacy gate.

### Employee invite
`created -> delivered -> verified -> pending_approval -> active` or `expired | rejected | cancelled`. If verification is complete but approval pending, login has **no data access**. Scope and role grants are atomic with activation; a reporting manager link grants no extra scope.

### Tenant portal activation
Landlord registers tenant party/person -> sends invitation -> email ownership verified -> staff/landlord approves -> scoped `tenant_portal_grant` activates. A co-tenant sees only their own private records plus explicitly classified *shared lease facts*. Payment details/proofs and identity documents of the other tenant remain private.

### Organisation transfer
`requested -> outgoing_access_revocation_approved -> old_membership_revoked -> new_org_invitation -> new_org_approved -> new_membership_active`. Use a single controlled transition for old/new membership if possible; never allow both active, including during retry. Disable existing session until re-authentication. Audit preserved by old membership IDs. For tenant changes of email, use `identity_email_change_requests`, not transfer of lease/legal obligations.

### Owner transfer
Initiated by owner or platform-supervised recovery -> independent identity re-verification and high-risk approval -> new owner active -> previous appointment ended -> new owner appointment created atomically; block owner deletion, self-service silent replacement and ownerless active organisation.

## Default permissions and separation of duties

- Owner configures roles and approves high-authority actions, but may not bypass immutable ledger and cannot silently self-approve their own refund if maker/checker separation applies.
- Financial verifier may verify payment after independent evidence; **cannot verify their own manually entered receipt**. Refund maker, approver and payout confirmer must be distinct where there are at least three eligible principals; otherwise require additional platform-authorised review or block.
- Landlord/caretaker roles receive no sensitive ID/payment proof by default. Tenant portal users never receive other tenants' private files, even under a shared lease.
- Approval requires distinct requester and approver for refunds, deposit deductions, manual journal adjustments, expense payments above threshold, owner transfer, privileged grants and clearance. For small organisations with insufficient eligible approvers, enrol an independent authorised approver or defer the action; **no automatic exception** or privileged platform override.
- MFA for all owner/admin/finance/approvers. No feature flag may disable server-side role/scope/organisation checks.

## Mandatory identity tests

- Duplicate email in mixed case/Unicode/IDN is rejected across orgs, including pending conflicting invites; public error messages do not disclose account membership.
- Account can hold employee and tenant capabilities in the **same** organisation without a duplicate login.
- No account can have simultaneous active/reserved access in two organisations. Employee who transfers retains audit history in former organisation but loses all access.
- Owner cannot become null/revoked while organisation active; concurrent owner transfer is serialised.
- A tenant person without portal login can exist, but cannot see any data until invitation/contact verification/approval.
- Supervisor relationship cannot widen property scope. Revocation takes effect immediately against Rust core and worker access.
