# AMAALPROP — Product Policy and PRD Open-Question Resolution v2

**Date:** 13 November 2026. **Status:** Selected implementation defaults, requiring product-owner adoption and external professional sign-off where noted.  
**Source:** `AMAALPROP_Product_Requirements_Document_v1.md`, section 30 (12 open questions) and Architecture v1 section 20 (additional engineering questions). This document makes the previously implicit choices explicit without falsely claiming statutory approval.

## The twelve PRD questions — specific resolutions

| # | Open question from PRD v1 | Selected v2 policy | Sign-off / limitation |
|---|---|---|---|
| 1 | Organisation verification | Owner confirms email/phone and accepts terms; individual landlord submits a valid identity/authority document as applicable; incorporated landlord supplies business registration and authorised-representative evidence; management company supplies a management mandate for properties it manages. Platform reviewer activates org after risk-based document verification. Sensitive files are private, minimal and retention-limited. | Confirm legal necessity for specific IDs/ownership proof and avoid mandatory over-collection |
| 2 | Organisation transfer | Request -> old organisation access revoked -> new org invite -> verified email/re-authentication -> new org approval -> new membership; old audit remains tied to old membership. No overlapping active/reserved memberships. | Engineering policy fixed; exception must be new ADR |
| 3 | Does one-email rule include tenants? | **Yes.** Applies to every portal login: owner, employee, tenant, contractor, representative, auditor. A tenant party/person can exist in several landlord organisations as a non-login profile, but a **single** email login cannot access more than one at once. | Deliberate UX limitation; product owner should acknowledge before launch |
| 4 | Joint liability among co-tenants | No implied joint-and-several liability. Each lease explicitly records liability mode: `individual_allocated` (default: approved shares sum to 100% of a charge) or `joint_contractual` (only if signed lease terms support it). Charge allocation/collection views must follow that selected agreement, not automatic duplication of each party's debt. | Legal review of enforceability and forms in Uganda |
| 5 | Occupant portal access | By default **none**. Explicit representative/occupant grant may see assigned unit-related notices, maintenance ticket updates and their own contact record; no rent balances, other occupants' IDs, payments, deposit or lease-signing authority unless expressly authorised by legal tenant/owner policy. | Consent/contract/guardian rules if minors involved; minimise child data |
| 6 | Cash payments in first release | **Disabled.** Allow only external bank/mobile-money instructions and independent receipt verification. Do not show `cash_office` instruction for live transactions until tills, cash custody, dual count, receipt control and reconciliation are separately approved. | New approval/business process for future cash feature |
| 7 | Country tax and statutory reports | Launch with configurable, effective-dated Ugandan tax codes, exemptions and withholding rules, but **no guessed tax rate**. A qualified Uganda accountant must approve each applicable treatment; invoice issue blocks when required tax treatment is unknown. | Accountant/tax counsel before live invoicing |
| 8 | Cash vs accrual | One **accrual** double-entry ledger for all customers. Optional cash-basis **reports** derive from posted transactions. No accounting-basis toggle that changes historic ledger event treatment. | Accountant approves policy and reporting format |
| 9 | Foreign currency | Launch with Ugandan organisation base currency **UGX** and UGX-only lease charges, payments, journal posting and deposits; preserve currency columns and FX snapshot schema, but disable conversion/FX postings until separate expert-reviewed release. | International expansion ADR + finance sign-off |
| 10 | Approval requester/approver separation | Mandatory for refunds, deposit deductions, finance adjustments/reversal approvals, supplier disbursements, privileged role grants, ownership transfer and final clearance (caretaker -> manager -> finance -> final approver). Other operations use versioned policies. A sole owner cannot silently override maker/checker: enrol an independent authorised delegate or block. | Organisation-configurable delegates cannot exceed authority; no auto self-approval |
| 11 | Tenant email or lease transfer | Email change: confirm control of new email, check global uniqueness, re-authenticate/revoke prior sessions, update IdP mapping and audit. **Lease transfer/novation** is a separate document-and-approval process; never change who owes rent just by changing a login or email. New legal tenant joins lease only via approved lease amendment/novation. | Landlord/legal agreement validation required |
| 12 | Retention | Versioned, per-data-category schedules and legal holds, with provisional internal defaults: financial 7y, lease 7y after end, raw ID 90d after purpose ends, inspections 3y, redacted logs 30d; back-up default 30d. **These are NOT statutory minima.** Block production sign-off until Uganda counsel/accountant reviews and changes them as required. | DPO/counsel and finance sign-off; enforce deletion and subject rights |

## Additional architecture decisions previously left open

| Topic | Selected implementation policy |
|---|---|
| SaaS plans/payment collection | Begin with one controlled pilot/free or contract-managed organisation plan, feature flags and tenant-safe soft quotas. **No automatic landlord subscription billing through the tenant rent ledger.** Later separate subscription billing module and distinct accounting. |
| Owner role vs external title ownership | Exactly one accountable current platform owner; legal title and third-party management documentation are separate property records, not extra organisation owners. |
| Joint leases with several units | `lease_units` many-to-many link. Occupancy and liability policy checked per unit/participant, capacity snapshots preserved. |
| Tax code rate changes | New effective-date record, never retroactive mutation of issued invoice; credit note or lawful adjustment workflow for corrections. |
| Payment shortfall / claimed vs cleared | Mark discrepancy `disputed`; never silently verify a different amount from claimant's submission. Confirm corrected amount and record original claim/audit before posted verification. |
| Owner-only finance operations | When independent approval required, recruit a verified, scoped finance delegate (not an imaginary platform operator) or keep operation pending. |
| Production hosting | Frankfurt technical candidate, **not** legally approved under Uganda cross-border provisions. Real identifiable data withheld until DPO/counsel completes assessment, registration and relevant DPAs. |
| Data subject access/correction | Data subject requests are tracked, scoped and decided by trained staff with statutory timelines; no deletion of posted finance records when retention/legal hold requires preservation, use data minimisation/redaction where lawful. |

## Default approval policy: first organisation setup

- Lease activation/variation: requester and approver must be separate if terms materially affect finances or occupancy, and the approver must have explicit lease authority.
- Expense authorisation and supplier payments: all disbursements require an independent approver at launch; thresholds can be configurable only after reviewed policy version is published.
- Refunds, deposit deductions, manual journal adjustments, payment reversals and owner transfer: independent approval **always**, regardless of amount.
- Tenant activation: authorised organisation owner/property manager review after contact verification; a self-created tenant portal grant cannot activate itself.
- Final clearance: caretaker inspection, separate manager verification, finance settlement, authorised owner/delegate decision, handover; finance/physical/legal statuses must remain independent.
- Any inability to satisfy the required number of independent approvers results in a pending/blocked action with a clear UX message, not automatic approval.

## Product-owner adoption record

These choices are implementation defaults because the user requested the previously missing decisions to be settled before engineering. They were **not already locked by the original PRD** where the PRD expressly posed a question. When the product owner adopts them, attach a versioned ADR/approval in the repository; if the policy changes, require a deliberate migration and negative/regression tests rather than quietly changing an enum or permission rule.

**Non-negotiable external gates:** Uganda data protection cross-border rules, operator/landlord registration requirements, tax treatments, deposit/legal notice rules and statutory retention cannot be certified through technical design alone. The platform can be scaffolded/tested on synthetic data while those approvals are obtained.
