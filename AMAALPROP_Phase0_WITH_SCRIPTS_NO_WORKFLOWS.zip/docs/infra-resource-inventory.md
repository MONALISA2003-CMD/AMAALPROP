# AMAALPROP provider/resource verification — 13 November 2026

Read-only inventory, no resources created/edited.

| Provider | Exact AMAALPROP identity | Status |
|---|---|---|
| GitHub | MONALISA2003-CMD/AMAALPROP | Found; current main is design docs only |
| Neon | amaalprop-v2-staging / royal-flower-91615135 | Found; PostgreSQL 17, Frankfurt |
| Neon staging | br-steep-block-b9j1xe3k / `amaalprop` database | Found, no app tables; migrator role only |
| Neon development | br-still-cloud-b9ox6qx0 | Found, synthetic probe table and runtime+migrator roles |
| Render | expected AMAALPROP core/gateway/worker | **Not in connected workspace's service listing** |
| Vercel | AMAALPROP web connected to repo | Not verified; intentionally deferred |
| Cloudflare | AMAALPROP domain and R2-specific bucket | Not verified; do not reuse others |

The user reports Render AMAALPROP services were created. This inventory does not
contradict that experience; it identifies a **workspace/account visibility mismatch**.
Provider account/service identification must be resolved before changing any Render
resource or deploying a Blueprint. No other projects were modified.
