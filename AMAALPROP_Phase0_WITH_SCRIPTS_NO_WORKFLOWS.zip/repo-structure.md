# AMAALPROP — Definitive Monorepo Structure v2 (Rust + NestJS)

**Prepared:** 13 November 2026. **Status:** Ready to scaffold; not an existing deployed repo.  
**Companion docs:** `docs/architecture-v2.md`, `docs/identity-membership-v2.md`, `docs/AMAALPROP_ERD_v2_FINAL.md`, `docs/financial-workflows-v2.md`, `docs/hosting-data-protection-v2.md`, `docs/product-policy-decisions-v2.md`, `phases.md`.

## The repository to create

**GitHub repository:** `amaalprop` (private, one monorepo).  
**Primary rule:** NestJS is the public API/BFF **gateway**, Rust/Axum is the **only business state owner**; Rust background worker shares Rust domain crates; Next.js web, optional Python AI. **Do not build both a NestJS property-management module and a Rust property-management module.**

```text
amaalprop/
├── README.md
├── CONTRIBUTING.md
├── SECURITY.md
├── CODEOWNERS
├── LICENSE                             # choose a license; private default
├── .gitignore
├── .editorconfig
├── .env.example                        # placeholders only; no secrets
├── pnpm-workspace.yaml                 # Next.js + NestJS + TS packages
├── package.json                        # root TS checks/scripts
├── pnpm-lock.yaml
├── Cargo.toml                          # root Rust workspace
├── Cargo.lock
├── rust-toolchain.toml                 # pinned stable toolchain
├── .cargo/config.toml
├── justfile                            # repeatable dev/test commands
├── compose.yaml                        # local DB + gateway + core + worker + web
├── compose.override.example.yaml
├── phases.md                           # delivery plan and exit gates
│
├── .github/
│   ├── workflows/
│   │   ├── ci-frontend.yml
│   │   ├── ci-nest-gateway.yml
│   │   ├── ci-rust.yml
│   │   ├── ci-postgres-security.yml
│   │   ├── ci-contracts.yml
│   │   ├── ci-end-to-end.yml
│   │   ├── ci-supply-chain.yml
│   │   ├── deploy-staging.yml
│   │   └── promote-production.yml
│   ├── dependabot.yml
│   ├── CODEOWNERS
│   └── pull_request_template.md
│
├── apps/
│   ├── web/                             # Vercel: Next.js / React / TypeScript
│   │   ├── public/
│   │   ├── src/
│   │   │   ├── app/
│   │   │   │   ├── (marketing)/
│   │   │   │   ├── (auth)/                # Auth0 login, invites, recovery
│   │   │   │   ├── (workspace)/          # owner/staff workflows
│   │   │   │   ├── (tenant)/             # tenant portal
│   │   │   │   └── api/                  # same-origin authenticated BFF proxy
│   │   │   ├── features/
│   │   │   │   ├── organisations/
│   │   │   │   ├── identity-access/
│   │   │   │   ├── property/
│   │   │   │   ├── tenants/
│   │   │   │   ├── leases/
│   │   │   │   ├── approvals/
│   │   │   │   ├── accounting/
│   │   │   │   ├── billing/
│   │   │   │   ├── payments/
│   │   │   │   ├── supplier-payables/
│   │   │   │   ├── maintenance/
│   │   │   │   ├── inspections-clearance/
│   │   │   │   ├── documents/
│   │   │   │   ├── communications/
│   │   │   │   └── reporting/
│   │   │   ├── components/
│   │   │   ├── lib/auth/
│   │   │   ├── lib/api/                 # generated public API client
│   │   │   └── styles/
│   │   ├── tests/
│   │   ├── next.config.ts
│   │   ├── package.json
│   │   ├── vercel.json                   # compute region, cache policy
│   │   └── .env.example
│   │
│   ├── api-gateway/                     # Render PUBLIC: NestJS REST API
│   │   ├── src/
│   │   │   ├── main.ts
│   │   │   ├── app.module.ts
│   │   │   ├── common/
│   │   │   │   ├── auth/                 # OIDC JWT verification
│   │   │   │   ├── guards/               # gateway route guards (not sole auth)
│   │   │   │   ├── filters/              # safe consistent error codes
│   │   │   │   ├── interceptors/         # traces/timeouts/no-store
│   │   │   │   ├── validation/
│   │   │   │   ├── rate-limits/
│   │   │   │   └── internal-delegation/   # signed short-lived assertions
│   │   │   ├── core-client/              # generated from Rust internal API
│   │   │   ├── api-v1/
│   │   │   │   ├── organisations/
│   │   │   │   ├── identity-access/
│   │   │   │   ├── property/
│   │   │   │   ├── tenant-leases/
│   │   │   │   ├── approvals/
│   │   │   │   ├── accounting/
│   │   │   │   ├── billing-payments/
│   │   │   │   ├── maintenance-clearance/
│   │   │   │   ├── documents/
│   │   │   │   └── reports/
│   │   │   └── health/
│   │   ├── test/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   └── Dockerfile
│   │
│   ├── core-api/                        # Render PRIVATE: Rust/Axum
│   │   ├── src/
│   │   │   ├── main.rs
│   │   │   ├── bootstrap.rs
│   │   │   ├── internal_routes/
│   │   │   │   ├── auth_context.rs
│   │   │   │   ├── commands.rs
│   │   │   │   ├── queries.rs
│   │   │   │   └── file_authorisation.rs
│   │   │   └── middleware/               # service JWT, request context
│   │   ├── tests/
│   │   ├── Cargo.toml
│   │   └── Dockerfile
│   │
│   ├── worker/                          # Render background worker: Rust
│   │   ├── src/
│   │   │   ├── main.rs
│   │   │   ├── outbox_dispatch.rs
│   │   │   ├── schedules/
│   │   │   │   ├── invoice_cycles.rs
│   │   │   │   ├── late_reminders.rs
│   │   │   │   ├── lease_expirations.rs
│   │   │   │   └── retention_jobs.rs
│   │   │   ├── consumers/
│   │   │   └── dead_letter.rs
│   │   ├── Cargo.toml
│   │   └── Dockerfile
│   │
│   └── ai-service/                      # Later, optional Render PRIVATE: Python
│       ├── app/
│       │   ├── main.py
│       │   ├── security/
│       │   ├── document_extraction/
│       │   ├── permission_filtered_rag/
│       │   ├── workflows/
│       │   └── observability/
│       ├── tests/
│       ├── pyproject.toml
│       ├── uv.lock
│       └── Dockerfile
│
├── crates/                              # Rust Cargo workspace, domain-owned once
│   ├── core-domain/
│   │   └── src/
│   │       ├── lib.rs
│   │       ├── shared/                  # tenant context, decimal, events
│   │       └── modules/
│   │           ├── platform/
│   │           ├── identity_access/
│   │           ├── property/
│   │           ├── tenant/
│   │           ├── lease/
│   │           ├── approvals/
│   │           ├── billing/
│   │           ├── payments/
│   │           ├── accounting/
│   │           ├── suppliers/
│   │           ├── reconciliation/
│   │           ├── maintenance/
│   │           ├── inspections_clearance/
│   │           ├── communications/
│   │           ├── documents/
│   │           ├── reporting/
│   │           └── audit_governance/
│   ├── persistence/
│   │   └── src/
│   │       ├── pool.rs
│   │       ├── tenant_transaction.rs     # SET LOCAL, fail-closed RLS
│   │       └── repositories/
│   ├── integrations/
│   │   └── src/
│   │       ├── object_storage.rs        # private R2
│   │       ├── email.rs                 # Resend adapter later
│   │       ├── bank_evidence.rs
│   │       └── auth_provider.rs
│   ├── api-contracts/
│   │   └── src/                        # serde/utoipa public internal DTOs
│   └── test-support/
│       └── src/                        # synthetic orgs, RLS/finance fixtures
│
├── packages/
│   ├── api-client/                       # generated typed public REST client
│   ├── core-internal-client/             # generated TS client for Nest -> Rust
│   ├── ui/                               # shared accessible components
│   ├── design-tokens/
│   ├── config-eslint/
│   └── config-typescript/
│
├── contracts/
│   ├── public-api/openapi.yaml           # source: NestJS API schema
│   ├── internal-core/openapi.yaml        # source: Rust utoipa schema
│   ├── events/                           # versioned business/outbox schemas
│   └── errors/                           # stable cross-language error codes
│
├── database/
│   ├── migrations/                       # SQLx files, ordered schema changes
│   ├── seeds/
│   │   ├── permissions.sql
│   │   ├── chart-of-accounts.template.sql
│   │   └── synthetic-dev-only.sql
│   ├── policies/                         # reviewed RLS policy references
│   ├── functions/                        # journal/immutability constraints
│   ├── tests/
│   │   ├── rls-negative/
│   │   ├── same-org-fks/
│   │   ├── financial-invariants/
│   │   └── migrations/
│   └── README.md
│
├── infrastructure/
│   ├── render/render.yaml                # Nest public, Rust private, worker; AI later
│   ├── vercel/README.md                  # project root apps/web, fra1 checks
│   ├── neon/README.md                    # branches/roles/PITR/restore procedure
│   ├── cloudflare/                       # DNS/WAF/cache rules; no secrets
│   ├── r2/README.md                      # new EU-jurisdiction private buckets
│   ├── auth0/README.md                   # single tenant, audience/MFA/config
│   ├── resend/README.md                  # sender, templates, webhook validation
│   └── monitoring/README.md
│
├── tests/
│   ├── end-to-end/                       # Playwright landlord/tenant journeys
│   ├── security/                         # org leakage, roles, CSRF, API service auth
│   ├── resilience/                       # failure and retry drills
│   ├── load/                             # concurrency: rent, payment, clearance
│   └── contract/                         # Nest public vs Rust internal compatibility
│
├── docs/
│   ├── START-HERE.md
│   ├── architecture-v2.md
│   ├── identity-membership-v2.md
│   ├── AMAALPROP_ERD_v2_FINAL.md
│   ├── financial-workflows-v2.md
│   ├── hosting-data-protection-v2.md
│   ├── product-policy-decisions-v2.md
│   ├── api-conventions.md
│   ├── runbooks/
│   │   ├── incident-response.md
│   │   ├── database-restore.md
│   │   ├── key-rotation.md
│   │   └── manual-payment-verification.md
│   ├── decisions/
│   │   ├── ADR-001-rust-plus-nest-gateway.md
│   │   ├── ADR-002-email-membership-owner.md
│   │   ├── ADR-003-financial-posting.md
│   │   ├── ADR-004-workflow-approvals.md
│   │   └── ADR-005-hosting-data-protection.md
│   └── reference/                       # original v1 documents, read-only history
│       ├── PRD-v1.md
│       ├── ERD-v1.md
│       ├── architecture-v1.md
│       └── tech-stack-v1.md
│
└── scripts/
    ├── bootstrap.sh
    ├── generate-api-clients.sh
    ├── verify-rls.sh
    ├── seed-synthetic-orgs.sh
    └── check-no-secrets.sh
```

## Ownership contract (do not violate)

| Concern | Authoritative owner | Other components |
|---|---|---|
| Login/IdP identity subject | Auth0 | Next holds session; Nest validates JWT; Rust maps and authorises account/org membership |
| Organisations/owners/membership/roles/scopes | Rust `identity_access`/`platform` | Nest exposes API; Next renders |
| Properties, units, tenants, leases, approvals | Rust domain modules | Nest transports/aggregates, worker uses same modules |
| Invoices, collections, refunds, accounts/journals | **Rust only** | Nest has no SQL/financial posting logic; Next cannot write journals |
| Email/SMS delivery | Rust outbox job and adapter, or Nest presentational integration without finance state | Delivery never approves a payment |
| Document storage access | Rust authorisation + R2 adapter | Next/Nest can proxy intent but cannot mint arbitrary privileged URLs |
| AI recommendations | Optional Python service with Rust-authorised context | Never has a posting credential/privileged SQL |
| SQL migrations | `database/migrations` reviewed by Rust/database/security owners | No NestJS ORM migrations against business tables |
| API contract | NestJS public OpenAPI + Rust internal OpenAPI | Generate clients; CI detects drift |

## Runtime boundaries and environments

- **Browser -> Next.js**: HttpOnly server session, same-origin BFF route handlers, CSRF protection, no sensitive data publicly cached.
- **Next.js -> NestJS**: server-issued identity token to public `https://api.<domain>/api/v1` endpoint; auth/rate/validation at gateway.
- **NestJS -> Rust private**: Render internal hostname + signed and audience-limited request assertion; Rust re-reads active membership/scope, opens tenant-local transaction.
- **Rust/worker -> Neon**: restricted roles with RLS and `SET LOCAL`; same-region network distance measured. Database is external Neon, not Render-native internal DB.
- **Rust/worker -> R2**: private S3 bucket with EU jurisdiction selected on **creation**, short-lived authorised access, no public bucket and no accidental multi-tenant object namespace leaks.
- **Environments:** local (synthetic), CI ephemeral/synthetic, staging (synthetic or legally anonymised), production (only after legal gate). Separate Neon projects/branches, R2 buckets, Auth0 applications and provider secrets.
- **Hosting example:** Render Frankfurt public `amaal-api-gateway`, private `amaal-core`, worker `amaal-worker`; Vercel web `amaal-web`; AI deferred. Do not reuse unrelated existing services.

## First commit — minimum actual files

Scaffold initially only:

1. Repository policies, `pnpm` + Cargo workspaces, root scripts, Compose and `.env.example`.
2. Minimal Next app with synthetic authentication stub (replace with Auth0 in Phase 1).
3. Minimal Nest gateway `GET /api/v1/health` validating contract; minimal Rust private `/internal/v1/health` with signed-service auth; Rust worker health/status.
4. PostgreSQL local container, empty migration runner and RLS test harness; **no production data, migrations or cloud credentials**.
5. All v2 docs under `docs/`, `phases.md` at root, original v1 docs under `docs/reference`.
6. A CI pull request that verifies web/gateway/Rust builds, contract generation and container smoke test.

Use `just dev`, `just test`, `just test-security`, `just migrate-local`, `just contract-check`, `just ci` as the canonical commands. Choose and pin dependency versions at scaffold time; do not depend on 'latest' for reproducibility. Never put `.env`, R2 keys, database URLs or identity-provider credentials in Git.

## Connector/provisioning checklist before deployment

GitHub, Vercel, Render, Neon, Cloudflare and Resend connectors were readable during the review; **that is not proof of scoped write permissions for this new project**. GitHub App had no accessible installations. Auth0/SMS/monitoring need new credentials or provider onboarding. Every resource-creation step waits for a verified project/account/region and explicit human authorisation. No provider resources were changed by the documentation work.

## Anti-patterns this design forbids

- Two sources of truth (one finance implementation in Nest and another in Rust).
- NestJS Prisma/TypeORM data writes to organisation-owned tables.
- Rust exposed directly as a public financial API.
- Browser-supplied organisation ID used as authorisation authority.
- Worker/AI operating without tenant context or RLS.
- Editing/deleting posted journal lines, self-approving refunds, treating screenshots as cleared cash.
- Premature Kafka, Kubernetes, compulsory microservices, or a C++ dependency.

## Definition of repository-ready

A new contributor can clone, run local synthetic development, pass CI, test a denied cross-organisation read, see the Nest -> Rust authenticated request, apply migrations and understand exactly which module owns any new entity or action. **Repository-ready does not mean legally production-ready.**
