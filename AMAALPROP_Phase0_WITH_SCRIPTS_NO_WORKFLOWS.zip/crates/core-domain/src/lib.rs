pub fn require_synthetic_mode() {
    assert_eq!(
        std::env::var("DATA_MODE").as_deref(),
        Ok("synthetic"),
        "Only synthetic data is supported in Phase 0"
    );
}
