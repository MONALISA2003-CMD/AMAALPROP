# AMAALPROP — Implementation Phases v2 (Rust + NestJS, resolved design baseline)

**Version:** 2.0 — 13 November 2026. **Status:** Implementation plan; no actual code/deployments performed.  
**Canonical decisions:** `docs/architecture-v2.md`, `docs/identity-membership-v2.md`, `docs/AMAALPROP_ERD_v2_FINAL.md`, `docs/financial-workflows-v2.md`, `docs/hosting-data-protection-v2.md`, `docs/product-policy-decisions-v2.md`, `repo-structure.md`.  
**Rule of execution:** Do **not** begin Phase N+1 until the exit gate for its prerequisites passes, except parallel documentation/UI work using synthetic data. Security/RLS/finance tests continue in every later phase.

## Design decisions resolved before Phase 0

- [x] **Use both languages:** Next.js on Vercel, **NestJS public API gateway** on Render, **Rust/Axum authoritative modular core as Render private service**, Rust worker on Render. Python AI later; no dual-written business state.
- [x] **Identity:** One global verified/canonical email identity; maximum one active/reserved organisation membership across all staff and tenant-portal logins; one membership may have multiple capacities in *one* org; one current owner per active org; controlled transfers.
- [x] **Authorisation:** Rust independently enforces membership+role+scope+workflow state, RLS and composite org FKs even when called from NestJS.
- [x] **Finance:** UGX-only initial operations, accrual journals, no unreviewed tax defaults, immutable posted entries, reversible source-linked postings, refundable deposit liability, unapplied receipt liability, independent payment evidence, refund/receipt/supplier/reconciliation lifecycle.
- [x] **Clearance:** Separate physical inspection, financial settlement and legal termination states; reusable policy-versioned approval engine and maker/checker.
- [x] **Hosting topology:** Frankfurt candidate for Render core/gateway/worker + Neon, Vercel with controlled compute region, separate new EU-jurisdiction R2 storage, Cloudflare edge; real Ugandan data blocked pending legal/compliance clearance.
- [x] **Missing logical ERD entities:** Fully enumerated in the v2 ERD and assigned to implementation phases.

The `[x]` above means **the design decision has been documented in this planning package**, not that implementation, user approval, legal certification, or infrastructure provisioning has occurred. The product owner should adopt the v2 decisions before code is merged.

## Release map

| Phase | Main outcome | Prerequisites | User-visible value |
|---|---|---|---|
| **P0** | Monorepo, Nest-to-Rust trust boundary, CI, synthetic staging | Design package | Functional dev environment |
| **P1** | Identity, organisations, owners, invitations, scopes, tenant RLS | P0 | Secure organisation sign-in/onboarding |
| **P2** | Properties, portfolios, buildings/levels, units, occupancy | P1 | Property inventory |
| **P3** | Tenants/occupants, multi-unit lease, versioned approvals | P2 | Leasing and controlled tenant portal |
| **P4** | Chart of accounts, periods, immutable balanced ledger | P3 | Auditable accounting core |
| **P5** | Billing, verified external payments, receipts, allocation, refund, reconciliation | P4 | Rent operations and tenant statements |
| **P6** | Suppliers, expenses, maintenance, inspections, move-out clearance | P5 | Complete property operations |
| **P7** | Notifications, files, dashboards, exports, retention and audit operations | P6 | Complete non-AI product |
| **P8 (optional)** | Permission-filtered AI extraction, search and reporting help | P1/P3/P7 | Assistive features only |
| **P9** | Security, restore, cross-border/legal readiness and production rollout | P0–P7; P8 only if launching it | Safe real-user production launch |
| **P10 (later)** | Mobile, multi-currency, bank APIs, commercial expansion | Production validated | Post-MVP growth |

## P0 — Engineering foundation and dual-language integration (revised after audit 2026-11-13)

**State:** IN PROGRESS. The uploaded snapshot is not proof that remote services are deployed.
P0 is **synthetic-only**; it must not modify production data or other projects.

### P0-A. Existing resources and repository

- [x] Confirm GitHub `MONALISA2003-CMD/AMAALPROP` repo exists; preserve original source docs.
- [x] Confirm Neon `amaalprop-v2-staging` exists (Frankfurt PostgreSQL 17), `staging` and `development` branches.
- [x] Inspect connected Render workspace: no AMAALPROP-named service returned; **user-reported services are not yet mapped**.
- [ ] Identify the actual AMAALPROP Render workspace and service IDs before any deployment or Blueprint sync.
- [ ] Confirm repository write permissions, create reviewed PR and make CI green.
- [ ] Define and enforce suitable branch/ruleset policies with collaborators and product owner.

### P0-B. Local, reproducible, signed service boundary

- [x] Provide Next.js web shell, NestJS gateway, Rust private Axum core, shared Rust crate and idle Rust worker.
- [x] Provide synthetic-only startup guard, least-scope signed Nest-to-Rust probe, negative tests for forged headers/tokens.
- [x] Provide Docker/Compose examples and pinned dependency lockfiles.
- [x] Provide provisional OpenAPI and its route drift check; generated clients are **not** implemented.
- [x] Replace persistent RLS test migration with a disposable, rolled-back local harness.
- [ ] Execute clean-clone `pnpm` build, Rust build/Clippy/tests, Docker builds, local boundary tests, ephemeral RLS SQL and GitHub Actions; record results.
- [ ] Scan images/dependencies and review security warnings before merging.

### P0-C. Real AMAALPROP infrastructure, not guessed names

- [ ] Compare *existing* AMAALPROP Render service details with `render.yaml` and resolve drift; do not create duplicates.
- [ ] Ensure core is Render `pserv` and gateway is `web` in the **same Frankfurt workspace/region**; worker is a background worker.
- [ ] Inject independent secrets via Render env values; use `fromService` only after service identification.
- [ ] Deploy and verify the signed private gateway->core probe; verify no public core origin and correct negative cases.
- [ ] Confirm AMAALPROP Neon staging DB role/branch selection and migrations policy. Do not connect the currently schema-less staging branch as production or use its migrator as runtime.
- [ ] Demonstrate a restricted, transaction-scoped runtime DB connection when P1 schema/roles are implemented; **not claimed complete at P0**.
- [ ] Record rollback plan, restore rehearsal owners, service/branch IDs and incident contacts.
- [ ] Vercel integration is **deferred** (build-only web shell is enough for P0 backend/local gate).

**P0 exit:** clean GitHub CI green; local tests pass; actual AMAALPROP Render gateway/core/worker IDs captured; deployed gateway reaches private Rust core with signed authentication; core has no public origin; no use of production tenant data; Neon environment boundaries documented. P1 is blocked until these gates are evidenced. Vercel is not required for P0 sign-off.

## P1 — Organisation and identity trust boundary

**Deliverables**

- [ ] Create `user_accounts`, `external_identities`, `organisation_memberships`, capabilities, one-current-owner appointments, employee profiles, invitation/reservation, transfer and email-change records.
- [ ] Implement canonical globally unique email and one live/reserved membership per account; prevent simultaneous cross-org invitations with an atomic reservation/lock.
- [ ] Integrate Auth0 OIDC PKCE, JWT verification, verified email, password recovery, owner/admin/finance MFA, secure Next session and sign-out revocation.
- [ ] Register organisation in pending state, verify founding owner email, review/approve activation, prevent active org without exactly one active owner.
- [ ] Invite employees, assign versioned roles/permissions/scope and supervisor independently; owner-transfer/organisation-transfer workflows record immutable history.
- [ ] Rust checks membership, scope, resource owner, workflow state and RLS in each protected transaction. Global account table operations are separately privileged and audited.
- [ ] Implement audit/security events; sensitive API fields redacted, no public record existence leakage, no user-supplied org trust.

**P1 exit gate:** Two seeded organisations cannot access each other's data through Nest, private Rust, DB runtime role or export; user with email in org A cannot activate org B; tenant+employee capabilities in same org work; revoked member loses access immediately; no ownerless active org, and no valid token alone yields org access.

## P2 — Property inventory and occupancy

- [ ] Migrate portfolios, properties, buildings, levels, unit types/units/features, policy version records, asset-scope assignments and indexes.
- [ ] Support standalone units (null building/level), custom unit codes, optional mixed-use properties and leaseable states.
- [ ] Create authorised create/edit/list APIs and responsive landlord/manager screens; server-side scope enforcement for property/building/unit.
- [ ] Implement occupancy policy snapshots, capacity counts and unit concurrency locking; property and occupancy events.

**P2 exit gate:** Property hierarchy covers standalone, multi-building and multi-level cases; unit code uniqueness within configured property scope; staff assigned to property A cannot manipulate B; no cross-org FK inserts; capacity policy changes are auditable.

## P3 — Tenant/lease/portal/approval foundation

- [ ] Migrate tenant parties/persons, contacts, IDs (private), occupants, portal grants, lease, lease units, participants, liability shares, events/amendments and concurrency protections.
- [ ] Tenant portal activation: invitation -> contact verification -> authorised approval, per-person privacy and co-tenant shared/private classifications.
- [ ] Lease drafts, explicit multi-unit/co-tenancy capacity checks, approval, activation, renewal, variation, notice and termination independent of clearance.
- [ ] Reusable approval schema: policies, immutable versions, steps, requests, decisions, delegation, escalation and source-version validation.
- [ ] Document storage flow: private upload intent, scan, classification, signed read access with Rust per-file permissions; no public cache.

**P3 exit gate:** Multi-unit lease and co-tenancy behave correctly; competing activations cannot overbook units; tenant A cannot read tenant B's ID/proof, even when sharing unit; refused/expired approval cannot activate lease; no cross-org document access.

## P4 — Financial ledger safety (HARD GATE)

- [ ] Migrate chart of accounts, accounting policies/periods, posting rules, immutable journals/lines, source links, reversal links, financial sequences and bank control accounts.
- [ ] Implement exact UGX decimal scale enforcement, open-period validation, journal balance DB guard, source/idempotency uniqueness and transaction-bound posting.
- [ ] Build account period open/close/reopen with independent approval and immutable audit; disallow direct posted journal update/delete, including DB service bypass.
- [ ] Build refundable deposit liability and unapplied tenant receipt liability accounts; prepare postings for AR, revenue, AP and tax mapping.
- [ ] Implement posting matrix and account reconciliation test fixtures with Rust domain services, not Nest writes.
- [ ] Independent finance engineer reviews money rounding, ledger integrity, reversal logic and concurrency safety.

**P4 exit gate:** Every posted journal has at least two valid lines and exactly balances; unbalanced/duplicate/wrong-currency/fractional UGX/closed-period posting fails; immutable original reversal is additive; no partial financial changes under injected worker/database failures. **Do not start live payment verification until this gate passes.**

## P5 — Billing and controlled collections (HARD GATE)

- [ ] Migrate charge types, rent policies, billing schedules/run items, invoices/lines, credit notes, tax mappings and financial-health policies.
- [ ] Deterministic calendar/proration and `UQ(org,schedule,cycle,policy_version)` safeguards; issue accrual journal atomically with invoice.
- [ ] Configure landlord bank/mobile-money instructions by scope; keep cash disabled; show tenant payment instructions but never claim payment is automatically captured.
- [ ] Migrate payment submissions, verification evidence, confirmed payments, payment events, receipt sequencing and unapplied credit movements.
- [ ] Independent finance review verifies real bank/mobile-money evidence; Rust atomic command creates posted payment, unapplied liability, numbered receipt and outbox. Submitter screenshots cannot verify.
- [ ] Allocate partial receipts to one/multiple invoices; derive balances and green/orange/red status from **posted** activity, not client edits.
- [ ] Build refunds, payment reversals, credit notes and deposit transfers with maker/checker, confirmation-before-disbursement-journal and unique sources.
- [ ] Migrate bank accounts, statement imports/lines, reconciliation/matching and reconciliation events; introduce safe manual statement matching.
- [ ] Add tenant/landlord statements; test duplicates, retries, full/partial/overpayments and disputed transactions.

**P5 exit gate:** One submission (or proof photo) creates zero journal until independent verification; verification/receipt and journal commit once, even under repeated concurrent calls; unallocated funds remain liability; funds/refunds do not exceed available balance; bank statement line matches cannot be duplicated; tax-uncertain invoice issuance blocked; full money E2E path passes.

## P6 — Supplier/AP, maintenance and clearance

- [ ] Migrate suppliers, bills/lines, AP journals, supplier disbursements and approval policies; no supplier payment before approval + confirmation.
- [ ] Maintenance requests, assignments, work orders, estimated/actual cost lines, contractor access and attachments; verify property scope and update history.
- [ ] Versioned inspection templates, per-unit inspections/evidence, caretaker submission and separate property-manager verification.
- [ ] Move-out requests and `clearance_cases`/case units, financial reviews and versioned deposit settlement proposals/deductions/disputes.
- [ ] Final landlord/delegate approval with independent authority, key handover and unit availability updates; legal termination independent from financial/physical clearance.
- [ ] Tenant and caretaker responsive mobile web flows, complete immutable chronology and restricted evidence access.

**P6 exit gate:** Caretaker cannot self-approve manager or final step; damage estimates do not automatically charge tenants; contested deductions remain disputed; approved deposit settlement reconciles to posted deposit liability; tenant may have lawful notice/termination even when other clearance items remain pending.

## P7 — Communications, reporting, governance and non-AI MVP

- [ ] Resend email delivery adapter through outbox; invitation, receipt, arrears, maintenance, renewal and approval notification templates/versioning; failed attempts retry without re-posting finance.
- [ ] In-app notifications; SMS optional only after vendor review, valid consent and secure configuration. Preserve communication history scoped to recipient.
- [ ] Landlord, manager, finance, caretaker and tenant dashboards and exports; every report scopes by org + role + property/party.
- [ ] Retention policy versioning, legal holds, data subject request/erasure workflow, file access logs, audit/export protections and redaction.
- [ ] Mobile-responsive accessibility, locale/timezone and date-rule checks. No public cache on authenticated reports/statements.
- [ ] Operations runbooks for manual verification, error triage, outbox replay, access revocation, privacy requests and backups.

**P7 exit gate:** Complete non-AI landlord->tenant->lease->rent->verify->receipt->maintenance->clearance journey works, exported reports match posted ledger, file URLs expire, duplicate messages do not cause duplicate business changes, tenant personal records remain isolated.

## P8 — OPTIONAL assistive AI, not a production prerequisite

- [ ] Decide AI provider/model region/cost, DPIA and processor terms before any real document ingestion.
- [ ] Add private Python FastAPI service, Rust-authorised per-request org/user/scope and strict read-only retrieval policy.
- [ ] Lease/document extraction with confidence, immutable review notes and human accept/reject; no direct posting or approval commands.
- [ ] Search across only permission-filtered files and data, with redaction, prompt-injection tests and model-version audit.

**P8 exit gate:** Cross-organisation retrieval impossible; low-confidence output cannot silently create facts; disabling AI leaves all core workflows functional.

## P9 — Production legal/security/recovery gate (BLOCKING)

- [ ] Uganda-qualified counsel/DPO validates operator roles, notices, registration/reporting, tenant data legal bases, processing contracts, cross-border path and onward transfers under Act s.19 and Regulations r.30. A Frankfurt location is **not** itself compliance approval.
- [ ] Complete DPIA for identity, tenant finance, document evidence and optional AI; obtain owner/DPO acceptance.
- [ ] Uganda accountant signs off chart, tax/withholding, payment/deposit, FX exclusion, accounting basis, reporting and retention policy.
- [ ] Confirm real provider regions/subprocessors, Auth0 app/identity data, Resend sender, Vercel Functions/failover, Render private network, Neon backup/PITR and R2 `eu` jurisdiction.
- [ ] Execute two-org API/RLS/storage/worker/report threat model, external penetration test or equivalent independent security review, full financial concurrency tests and restore drill.
- [ ] Validate evidence of database + R2 recovery against proposed **RPO <=1h / RTO <=8h**, or revise targets to achievable tested values.
- [ ] Prepare immediate breach escalation/notification playbook (not generic 72h), request rights workflow, retention/holds and incident operations.
- [ ] Protect production domain/TLS/WAF/cache and origin; disable unrelated provider projects and unnecessary public endpoints. Confirm secure rollback and customer support ownership.
- [ ] Product owner + engineering lead + DPO/legal sign release gate after verifying **every** applicable item and testing real-user onboarding under approved policy.

**P9 exit gate:** Written sign-offs and restore/security/finance evidence exist. If processing outside Uganda is not legally supportable, **production launch is blocked until hosting/processor model is changed and reassessed**. Engineering using synthetic data may continue before this gate.

## P10 — Post-launch expansion

- [ ] Multi-currency subledger, exchange-rate snapshots and realised/unrealised FX with accounting sign-off.
- [ ] Direct bank/mobile-money integrations, verified webhook origin/replay controls and automatic reconciliation (optional per landlord).
- [ ] Cash-office collection feature only with new safeguarding/cash till controls and maker/checker.
- [ ] Subscription plans and billing for AMAALPROP SaaS **separate from landlord/tenant ledger**.
- [ ] Mobile apps using public NestJS API with OAuth PKCE and scoped Rust authorisation.
- [ ] Expanded country rules, tax, retention, legal documents and tenant rights; C++/specialist compute only on measured need.

**P10 exit gate:** Each feature has its own ADR, tests, region/privacy review, backward-compatible migration and explicit rollout permission.

## Mandatory recurring tests at every phase

1. Two organisations never observe/modify each other's records, files, jobs or reports; global identity table does not leak memberships.
2. Nest cannot bypass Rust permission/RLS; forged service JWT, header, org ID and expired session denied.
3. Tenant co-tenant confidentiality, staff assignment restrictions and revocations are enforced against every API and report.
4. Financial effects happen once under retries, worker crashes and concurrent requests; journal posting is always balanced and immutable.
5. Payments remain unverified until independent real receipt evidence; refundable deposits remain liabilities; refund/approval separation respected.
6. Tenant clearance cannot be self-approved and remains independent of lawful lease status.
7. Signed file URLs expire and don't get CDN-cached; export has caller scope checks and audit.

## Decision/launch register

| Decision | Design status | Required external action |
|---|---|---|
| Rust core + NestJS gateway | Defined | Product owner/engineering adopt ADR |
| One-email/one-active-organisation rule incl tenant portal | Defined | Product owner adopt as deliberate restriction |
| Owner transfer + multi-capacity same org | Defined | Implementation tests |
| Entity inventory/migrations | Specified | DB migration build + independent review |
| UGX accrual, no cash and evidence-backed payment verification | Defined | Uganda accountant/finance policy sign-off before live finance |
| Deposit/refund/clearance separation | Defined | Lease/deposit legal policy sign-off |
| Frankfurt Vercel/Render/Neon + EU R2 technical topology | Selected | Actual region + vendor checks |
| Uganda cross-border processing and registration | **Not certified** | DPO/counsel, PDPO filings/assessment as applicable |
| Production retention periods | Provisional defaults | Counsel/accountant approve final schedules |
| Auth0 and Resend provider onboarding | Proposed/partly readable | Configure and verify appropriate product tenant/domain and DPA |
| GitHub repository-specific connector | **Repo exists; write permission unverified** | Verify GitHub App installation/scoped write permissions |

**Next action:** Review the repaired P0 branch, identify existing AMAALPROP Render services in the correct workspace, and run clean-clone tests. Do not migrate real customer data or issue live financial records before P9 sign-off.
