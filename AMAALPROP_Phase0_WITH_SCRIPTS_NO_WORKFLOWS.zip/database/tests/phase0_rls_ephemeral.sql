-- SELF-ROLLING-BACK synthetic RLS/security probe. For throwaway local Postgres ONLY.
-- All objects and rows are rolled back. No role or schema persists after success.
\set ON_ERROR_STOP on
BEGIN;
CREATE ROLE amaalprop_phase0_rls_test_role NOLOGIN NOSUPERUSER NOBYPASSRLS;
CREATE SCHEMA amaalprop_phase0_test;
REVOKE ALL ON SCHEMA amaalprop_phase0_test FROM PUBLIC;
CREATE TABLE amaalprop_phase0_test.organisation_probe (
    organisation_id uuid NOT NULL,
    id uuid NOT NULL,
    label text NOT NULL,
    PRIMARY KEY (organisation_id, id)
);
ALTER TABLE amaalprop_phase0_test.organisation_probe ENABLE ROW LEVEL SECURITY;
ALTER TABLE amaalprop_phase0_test.organisation_probe FORCE ROW LEVEL SECURITY;
CREATE POLICY enforce_org ON amaalprop_phase0_test.organisation_probe
    USING (organisation_id = NULLIF(current_setting('app.organisation_id', true), '')::uuid)
    WITH CHECK (organisation_id = NULLIF(current_setting('app.organisation_id', true), '')::uuid);
GRANT USAGE ON SCHEMA amaalprop_phase0_test TO amaalprop_phase0_rls_test_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON amaalprop_phase0_test.organisation_probe TO amaalprop_phase0_rls_test_role;
SET LOCAL ROLE amaalprop_phase0_rls_test_role;
-- No context means no reads, no writes.
DO $$ BEGIN
 IF (SELECT count(*) FROM amaalprop_phase0_test.organisation_probe) <> 0 THEN
  RAISE EXCEPTION 'Missing context must not read rows';
 END IF;
 BEGIN
  INSERT INTO amaalprop_phase0_test.organisation_probe VALUES
   ('00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','forbidden');
  RAISE EXCEPTION 'Missing context permitted insert';
 EXCEPTION WHEN insufficient_privilege THEN NULL;
 END;
END $$;
-- Org A writes a row.
SELECT set_config('app.organisation_id','00000000-0000-0000-0000-000000000001',true);
INSERT INTO amaalprop_phase0_test.organisation_probe VALUES
 ('00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000010','A');
-- Org B cannot read/update/delete Org A; cross-org insert fails RLS.
SELECT set_config('app.organisation_id','00000000-0000-0000-0000-000000000002',true);
DO $$ BEGIN
 IF (SELECT count(*) FROM amaalprop_phase0_test.organisation_probe) <> 0 THEN
  RAISE EXCEPTION 'Cross-org read leaked';
 END IF;
 IF (SELECT count(*) FROM amaalprop_phase0_test.organisation_probe WHERE organisation_id='00000000-0000-0000-0000-000000000001') <> 0 THEN
  RAISE EXCEPTION 'Cross-org filter leaked';
 END IF;
 BEGIN
  INSERT INTO amaalprop_phase0_test.organisation_probe VALUES
  ('00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000011','forbidden');
  RAISE EXCEPTION 'Cross-org insert succeeded';
 EXCEPTION WHEN insufficient_privilege THEN NULL;
 END;
 IF (SELECT count(*) FROM amaalprop_phase0_test.organisation_probe) <> 0 THEN
  RAISE EXCEPTION 'Cross-org read after failed write leaked';
 END IF;
END $$;
UPDATE amaalprop_phase0_test.organisation_probe SET label='wrong-tenant';
DELETE FROM amaalprop_phase0_test.organisation_probe;
-- Org A still sees its original row.
SELECT set_config('app.organisation_id','00000000-0000-0000-0000-000000000001',true);
DO $$ BEGIN
 IF (SELECT count(*) FROM amaalprop_phase0_test.organisation_probe WHERE label='A') <> 1 THEN
  RAISE EXCEPTION 'Cross-org update/delete altered another organisation';
 END IF;
END $$;
ROLLBACK;
-- Separate transaction with no inherited organisation context: no data and no tenant context.
BEGIN;
DO $$ BEGIN
 IF NULLIF(current_setting('app.organisation_id', true), '') IS NOT NULL THEN
  RAISE EXCEPTION 'Organisation context leaked across transactions';
 END IF;
END $$;
ROLLBACK;
