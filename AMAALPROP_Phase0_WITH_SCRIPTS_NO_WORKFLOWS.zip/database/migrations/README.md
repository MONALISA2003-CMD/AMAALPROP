# Real application migrations (not yet started)

Phase 0 is an infrastructure/trust-boundary foundation, not the financial/identity schema.
No production or staging migrations are applied by this repository at P0.

P1 owns the first approved schema migration, including migration-role permissions,
unique global emails, membership constraints, and tenant-enforced RLS.

**Never run the Phase 0 ephemeral RLS fixture as a migration.**
