use axum::{
    Json, Router,
    extract::State,
    http::{HeaderMap, StatusCode},
    routing::get,
};
use jsonwebtoken::{Algorithm, DecodingKey, Validation, decode};
use serde::Deserialize;
use serde_json::{Value, json};
use std::{
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};

#[derive(Debug, Deserialize)]
struct Claims {
    sub: String,
    iat: u64,
    exp: u64,
    method: String,
    path: String,
}
fn verify(token: &str, secret: &[u8]) -> Result<(), StatusCode> {
    let mut validation = Validation::new(Algorithm::HS256);
    validation.set_audience(&["amaalprop-core"]);
    validation.set_issuer(&["amaalprop-gateway"]);
    validation.set_required_spec_claims(&["exp", "nbf", "iss", "aud", "sub"]);
    validation.validate_nbf = true;
    validation.leeway = 2;
    let claims = decode::<Claims>(token, &DecodingKey::from_secret(secret), &validation)
        .map_err(|_| StatusCode::UNAUTHORIZED)?
        .claims;
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|_| StatusCode::UNAUTHORIZED)?
        .as_secs();
    if claims.sub != "synthetic-health-probe"
        || claims.method != "GET"
        || claims.path != "/internal/v1/health"
        || claims.iat > now + 2
        || claims.exp <= claims.iat
        || claims.exp - claims.iat > 30
    {
        return Err(StatusCode::UNAUTHORIZED);
    }
    Ok(())
}
async fn health(
    State(secret): State<Arc<String>>,
    headers: HeaderMap,
) -> Result<Json<Value>, StatusCode> {
    for key in ["x-organisation-id", "x-org-id", "x-user-id"] {
        if headers.contains_key(key) {
            return Err(StatusCode::UNAUTHORIZED);
        }
    }
    let token = headers
        .get("authorization")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.strip_prefix("Bearer "))
        .ok_or(StatusCode::UNAUTHORIZED)?;
    verify(token, secret.as_bytes())?;
    Ok(Json(
        json!({"status":"ok", "service":"core", "dataMode":"synthetic"}),
    ))
}
#[tokio::main]
async fn main() {
    core_domain::require_synthetic_mode();
    let secret = std::env::var("INTERNAL_SIGNING_SECRET").expect("Missing signing secret");
    assert!(secret.len() >= 32, "Signing secret too short");
    let app = Router::new()
        .route("/internal/v1/health", get(health))
        .with_state(Arc::new(secret));
    let port = std::env::var("PORT").unwrap_or_else(|_| "10001".into());
    let listener = tokio::net::TcpListener::bind(format!("0.0.0.0:{port}"))
        .await
        .unwrap();
    axum::serve(listener, app)
        .with_graceful_shutdown(async {
            tokio::signal::ctrl_c().await.ok();
        })
        .await
        .unwrap();
}
