import 'reflect-metadata';
import { Controller, Get, Headers, Module, UnauthorizedException, ServiceUnavailableException, Header } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { createHmac, timingSafeEqual, randomUUID } from 'node:crypto';

function required(name: string): string {
  const value = process.env[name];
  if (!value || value.length < 32) throw new Error(`${name} must contain at least 32 characters`);
  return value;
}
if (process.env.DATA_MODE !== 'synthetic') throw new Error('Only synthetic mode is supported in Phase 0');
const key = required('INTERNAL_SIGNING_SECRET');
const smokeKey = required('STAGING_SMOKE_TOKEN');
const host = process.env.CORE_HOST || '127.0.0.1';
if (!/^[a-zA-Z0-9.-]+$/.test(host)) throw new Error('Invalid core hostname');
const coreUrl = `http://${host}:${process.env.CORE_PORT || '10001'}/internal/v1/health`;
const encode = (v: unknown) => Buffer.from(JSON.stringify(v)).toString('base64url');
function assertion(): string {
  const now = Math.floor(Date.now() / 1000);
  const body = `${encode({alg:'HS256',typ:'JWT'})}.${encode({iss:'amaalprop-gateway',aud:'amaalprop-core',sub:'synthetic-health-probe',iat:now,nbf:now,exp:now+30,jti:randomUUID(),method:'GET',path:'/internal/v1/health'})}`;
  return `${body}.${createHmac('sha256',key).update(body).digest('base64url')}`;
}
@Controller('api/v1')
class HealthController {
  @Get('health')
  @Header('Cache-Control','no-store')
  health() { return {status:'ok',service:'gateway',dataMode:'synthetic'}; }

  @Get('core-health')
  @Header('Cache-Control','no-store')
  async coreHealth(@Headers() headers: Record<string,string|undefined>) {
    const token = headers.authorization || '';
    const expected = `Bearer ${smokeKey}`;
    if (Buffer.byteLength(token) !== Buffer.byteLength(expected) || !timingSafeEqual(Buffer.from(token),Buffer.from(expected))) throw new UnauthorizedException();
    if (headers['x-organisation-id'] || headers['x-org-id'] || headers['x-user-id']) throw new UnauthorizedException();
    try {
      const result = await fetch(coreUrl,{headers:{authorization:`Bearer ${assertion()}`},signal:AbortSignal.timeout(5000),redirect:'error'});
      if (!result.ok) throw new Error('Core unavailable');
      const data: unknown = await result.json();
      return {status:'ok',core:data};
    } catch { throw new ServiceUnavailableException('Core unavailable'); }
  }
}
@Module({controllers:[HealthController]})
class AppModule {}
async function main() {
 const app = await NestFactory.create(AppModule);
 app.enableShutdownHooks();
 await app.listen(Number(process.env.PORT || 10000),'0.0.0.0');
}
void main();
