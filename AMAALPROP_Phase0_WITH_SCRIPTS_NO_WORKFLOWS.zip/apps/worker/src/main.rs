#[tokio::main]
async fn main() {
    core_domain::require_synthetic_mode();
    println!("{{\"service\":\"worker\",\"status\":\"idle\",\"dataMode\":\"synthetic\"}}");
    // No business jobs before their domain phases and restricted DB roles exist.
    tokio::signal::ctrl_c().await.expect("shutdown listener");
}
