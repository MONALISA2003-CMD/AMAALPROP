export default function Home() {
 return <main style={{maxWidth:800,margin:'12vh auto',padding:32,fontFamily:'system-ui',color:'#16352d'}}>
 <p>AMAALPROP / ENGINEERING PREVIEW</p><h1>A dependable foundation for property operations.</h1>
 <p>Phase 0 is underway. This environment is reserved for synthetic test data.</p>
 <p>Sign-in, properties, leases and finance will become available in subsequent phases.</p>
 </main>;
}
