"""Offline safety tests for the AMAALPROP automatic ZIP importer."""
import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest
import zipfile
import sys

IMPORTER = Path(__file__).resolve().parents[2] / 'scripts/import_release_zip.py'
spec = importlib.util.spec_from_file_location('amaal_import', IMPORTER)
imp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(imp)


def write_zip(where: Path, files: dict[str, bytes | str]):
    where.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(where, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, content in files.items():
            archive.writestr(name, content)


def git(repo: Path, *args):
    return subprocess.run(['git', *args], cwd=repo, check=True, capture_output=True)


class ZipAutoImportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.repo = Path(self.tmp.name)
        git(self.repo, 'init', '-q')
        git(self.repo, 'config', 'user.email', 'test@example.test')
        git(self.repo, 'config', 'user.name', 'test')
        (self.repo / 'README.md').write_text('Existing repo\n')
        git(self.repo, 'add', '.'); git(self.repo, 'commit', '-qm', 'baseline')

    def import_all(self):
        names = imp.list_archives(self.repo)
        payload = imp.merge_archives(self.repo, names)
        return imp.apply_import(self.repo, names, payload)

    def test_auto_detect_zip_anywhere_uppercase_and_multiple(self):
        write_zip(self.repo / 'updates/anything.ZIP', {'AMAALPROP-release/apps/web/page.tsx': 'hello'})
        write_zip(self.repo / 'another/fix.zip', {'pages/phases.md': '# phase'})
        git(self.repo, 'add', '.')
        self.assertEqual(len(imp.list_archives(self.repo)), 2)
        self.import_all()
        self.assertEqual((self.repo / 'apps/web/page.tsx').read_text(), 'hello')
        self.assertEqual((self.repo / 'phases.md').read_text(), '# phase')
        self.assertFalse((self.repo / 'updates/anything.ZIP').exists())

    def test_do_not_strip_real_app_folder(self):
        path = self.repo / 'feature.zip'
        write_zip(path, {'apps/web/main.ts': 'ok'})
        self.assertEqual(list(imp.read_archive(path)), ['apps/web/main.ts'])

    def test_partial_updates_keep_old(self):
        write_zip(self.repo / 'one.zip', {'README.md': 'FIRST', 'apps/web/main.ts': 'v1'})
        git(self.repo, 'add', '.')
        self.import_all()
        git(self.repo, 'add', '.'); git(self.repo, 'commit', '-qm', 'import1')
        write_zip(self.repo / 'two.zip', {'apps/web/main.ts': 'v2'})
        git(self.repo, 'add', '.')
        self.import_all()
        self.assertEqual((self.repo / 'README.md').read_text(), 'FIRST')
        self.assertEqual((self.repo / 'apps/web/main.ts').read_text(), 'v2')

    def test_canonical_legacy_documents_and_duplicate_content(self):
        path = self.repo / 'docs.ZIP'
        write_zip(path, {
            'wrapper/docs/reference/PRD-v1.md': 'PRD',
            'wrapper/AMAALPROP_Product_Requirements_Document_v1.md': 'PRD',
            'wrapper/docs/redundant.md': 'PRD',
        })
        data = imp.merge_archives(self.repo, ['docs.ZIP'])
        self.assertEqual(data, {'AMAALPROP_Product_Requirements_Document_v1.md': b'PRD'})

    def test_reject_traversal(self):
        path = self.repo / 'bad.zip'
        write_zip(path, {'AMAALPROP/../README.md': 'evil'})
        with self.assertRaisesRegex(ValueError, 'unsafe path segment'):
            imp.read_archive(path)

    def test_reject_symlink(self):
        path = self.repo / 'bad.zip'
        with zipfile.ZipFile(path, 'w') as z:
            info = zipfile.ZipInfo('AMAALPROP/apps/payload.txt')
            info.create_system = 3
            info.external_attr = (0o120777 << 16)
            z.writestr(info, 'README.md')
        with self.assertRaisesRegex(ValueError, 'ZIP symlink forbidden'):
            imp.read_archive(path)

    def test_conflicting_archives_fail(self):
        write_zip(self.repo / 'x.zip', {'apps/web/a.ts': 'A'})
        write_zip(self.repo / 'y.zip', {'apps/web/a.ts': 'B'})
        with self.assertRaisesRegex(ValueError, 'disagree'):
            imp.merge_archives(self.repo, ['x.zip', 'y.zip'])

    def test_protect_importer_and_workflow_from_zip(self):
        path = self.repo / 'all.zip'
        write_zip(path, {
            'AMAALPROP/scripts/import_release_zip.py': 'evil',
            'AMAALPROP/.github/workflows/import-release-zip.yml': 'evil',
            'AMAALPROP/apps/web/page.tsx': 'correct',
        })
        self.assertEqual(imp.read_archive(path), {'apps/web/page.tsx': b'correct'})

    def test_reject_unknown_root_layout(self):
        path = self.repo / 'random.zip'
        write_zip(path, {'random-folder/file.txt': 'x'})
        with self.assertRaisesRegex(ValueError, 'recognized AMAALPROP root path'):
            imp.read_archive(path)

    def test_manual_edit_blocks_overwrite(self):
        write_zip(self.repo / 'one.zip', {'apps/web/main.ts': 'v1'})
        git(self.repo, 'add', '.')
        self.import_all()
        git(self.repo, 'add', '.'); git(self.repo, 'commit', '-qm', 'import1')
        (self.repo / 'apps/web/main.ts').write_text('manual change')
        write_zip(self.repo / 'two.zip', {'apps/web/main.ts': 'v2'})
        git(self.repo, 'add', '.')
        names = imp.list_archives(self.repo)
        with self.assertRaisesRegex(ValueError, 'manually edited imported file'):
            imp.apply_import(self.repo, names, imp.merge_archives(self.repo, names))
        self.assertEqual((self.repo / 'apps/web/main.ts').read_text(), 'manual change')

    def test_existing_identical_document_is_deduplicated(self):
        path = self.repo / 'docs' / 'reference' / 'PRD-v1.md'
        path.parent.mkdir(parents=True)
        path.write_text('same')
        (self.repo / 'AMAALPROP_Product_Requirements_Document_v1.md').write_text('same')
        write_zip(self.repo / 'next.zip', {'apps/web/page.tsx': 'new'})
        git(self.repo, 'add', '.')
        self.import_all()
        self.assertFalse(path.exists())
        self.assertTrue((self.repo / 'AMAALPROP_Product_Requirements_Document_v1.md').exists())

    def test_legacy_duplicate_archive_entry_dedupe(self):
        path = self.repo / 'repeat.zip'
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr('AMAALPROP/README.md', b'readme')
                z.writestr('AMAALPROP/README.md', b'readme')
        self.assertEqual(imp.read_archive(path), {'README.md': b'readme'})


if __name__ == '__main__':
    unittest.main()
