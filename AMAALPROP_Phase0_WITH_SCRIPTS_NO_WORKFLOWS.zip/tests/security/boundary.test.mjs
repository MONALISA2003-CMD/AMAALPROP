import test from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
const gateway = process.env.GATEWAY_URL || 'http://127.0.0.1:10000';
const core = process.env.CORE_URL || 'http://127.0.0.1:10001';
const secret = process.env.INTERNAL_SIGNING_SECRET;
function jwt(overrides={},key=secret) {
 const now=Math.floor(Date.now()/1000);
 const encode=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
 const body=encode({alg:'HS256',typ:'JWT'})+'.'+encode({iss:'amaalprop-gateway',aud:'amaalprop-core',sub:'synthetic-health-probe',iat:now,nbf:now,exp:now+30,method:'GET',path:'/internal/v1/health',...overrides});
 return body+'.'+createHmac('sha256',key).update(body).digest('base64url');
}
const check=async(url,headers,status)=>assert.equal((await fetch(url,{headers})).status,status);
test('gateway liveness',()=>check(gateway+'/api/v1/health',{},200));
test('public callers cannot invoke core probe',()=>check(gateway+'/api/v1/core-health',{},401));
test('gateway to private core succeeds',()=>check(gateway+'/api/v1/core-health',{authorization:`Bearer ${process.env.STAGING_SMOKE_TOKEN}`},200));
for (const [name,claims,key] of [['wrong audience',{aud:'wrong'}],['expired',{exp:1}],['wrong subject',{sub:'unknown'}],['wrong route',{path:'/internal/v1/payments'}],['excess lifetime',{exp:Math.floor(Date.now()/1000)+3600}],['wrong signature',{},'not-the-secret']]) {
 test('core rejects '+name,()=>check(core+'/internal/v1/health',{authorization:'Bearer '+jwt(claims,key)},401));
}
test('core rejects unsigned caller',()=>check(core+'/internal/v1/health',{},401));
test('core rejects forged tenant header',()=>check(core+'/internal/v1/health',{authorization:'Bearer '+jwt(),'x-organisation-id':'forged'},401));
test('gateway rejects forged tenant header',()=>check(gateway+'/api/v1/core-health',{authorization:`Bearer ${process.env.STAGING_SMOKE_TOKEN}`,'x-org-id':'forged'},401));
