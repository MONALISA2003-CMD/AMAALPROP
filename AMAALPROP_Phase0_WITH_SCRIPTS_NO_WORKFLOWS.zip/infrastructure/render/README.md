# Render Blueprint review gate

`../../render.yaml` is a **proposed configuration only**. Do not approve a Render
Blueprint sync unless the existing AMAALPROP service IDs, names, region, plan,
and repository linkage have been verified in the selected workspace.

Render currently returns **no AMAALPROP services** in the accessible workspace,
even though the project owner reports they exist. The correct action is to locate
the matching workspace and identify services, **not create duplicates**.

Gateway (web) -> Core (private) via Render `fromService`, with one shared generated
internal-signing secret for that pair; worker is a separate non-listening process.
No Neon `DATABASE_URL` is included until runtime database roles and Rust SQLx
transactions exist. No production data is allowed.
